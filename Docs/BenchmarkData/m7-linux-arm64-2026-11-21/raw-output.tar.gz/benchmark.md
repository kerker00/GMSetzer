swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.

[33mWarning: this project depends on the benchmark package using its legacy
identifier 'package-benchmark'. The repository has been renamed; please update
your Package.swift to use the new URL and identifier:

  .package(url: "https://github.com/ordo-one/benchmark", ...)
  .product(name: "Benchmark", package: "benchmark"),
  .plugin(name: "BenchmarkPlugin", package: "benchmark"),

Support for the legacy 'package-benchmark' identifier will be removed in a
future release.[0m

swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect path to swift-backtrace at 0x<address>; disabling backtracing.
swift runtime: unable to protect environment for swift-backtrace at 0x<address>; disabling backtracing.

## Baseline 'Current_run'

```
Host '<redacted>' with 4 'aarch64' processors with 7 GB memory, running:
#1 SMP PREEMPT Debian 1:6.18.60-1+rpt1 (2026-11-03)
```
## ParserBenchmarks

### GMSetzer 10k caret queries 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) *      |         0 |         0 |         0 |         0 |         0 |         0 |         0 |       777 |
| Malloc (total) *            |         0 |         0 |         0 |         0 |         0 |         0 |         0 |       777 |
| Time (wall clock) (μs) *    |      5271 |      5493 |      5599 |      6722 |      8446 |     14311 |     19784 |       777 |

### GMSetzer 10k caret queries 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) *      |         0 |         0 |         0 |         0 |         0 |         0 |         0 |      2601 |
| Malloc (total) *            |         0 |         0 |         0 |         0 |         0 |         0 |         0 |      2601 |
| Time (wall clock) (μs) *    |      1573 |      1629 |      1646 |      1961 |      2392 |      5255 |     13688 |      2601 |

### GMSetzer 10k caret queries 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) *      |         0 |         0 |         0 |         0 |         0 |         0 |         0 |       380 |
| Malloc (total) *            |         0 |         0 |         0 |         0 |         0 |         0 |         0 |       380 |
| Time (wall clock) (μs) *    |     10739 |     11158 |     11657 |     14197 |     16548 |     24609 |     33731 |       380 |

### GMSetzer 10k position round trips 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) *      |         0 |         0 |         0 |         0 |         0 |         0 |         0 |       915 |
| Malloc (total) *            |         0 |         0 |         0 |         0 |         0 |         0 |         0 |       915 |
| Time (wall clock) (μs) *    |      4918 |      4956 |      4997 |      5644 |      6595 |      9126 |     11649 |       915 |

### GMSetzer 10k position round trips 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) *      |         0 |         0 |         0 |         0 |         0 |         0 |         0 |      1095 |
| Malloc (total) *            |         0 |         0 |         0 |         0 |         0 |         0 |         0 |      1095 |
| Time (wall clock) (μs) *    |      4057 |      4090 |      4104 |      4727 |      5636 |      8118 |     21072 |      1095 |

### GMSetzer 10k position round trips 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) *      |         0 |         0 |         0 |         0 |         0 |         0 |         0 |       713 |
| Malloc (total) *            |         0 |         0 |         0 |         0 |         0 |         0 |         0 |       713 |
| Time (wall clock) (μs) *    |      6061 |      6132 |      6181 |      7299 |      8585 |     12386 |     32741 |       713 |

### GMSetzer CommonMark parse 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        59 |        59 |        59 |        59 |        59 |        59 |        59 |        38 |
| Malloc (total) (K) *        |       115 |       115 |       115 |       115 |       115 |       115 |       115 |        38 |
| Time (wall clock) (μs) *    |    105332 |    108462 |    130286 |    152961 |    181535 |    190545 |    190545 |        38 |

### GMSetzer CommonMark parse 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5890 |      5894 |      5894 |      5894 |      5894 |      5894 |      5894 |       424 |
| Malloc (total) (K) *        |        12 |        12 |        12 |        12 |        12 |        12 |        12 |       424 |
| Time (wall clock) (μs) *    |      8700 |      9036 |      9249 |     12534 |     17924 |     34767 |     60797 |       424 |

### GMSetzer CommonMark parse 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       294 |       294 |       294 |       294 |       294 |       294 |       294 |         9 |
| Malloc (total) (K) *        |       575 |       575 |       575 |       575 |       575 |       575 |       575 |         9 |
| Time (wall clock) (μs) *    |    539940 |    588775 |    619708 |    640156 |    770156 |    770156 |    770156 |         9 |

### GMSetzer GFM parse 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        88 |        88 |        88 |        88 |        88 |        88 |        88 |        34 |
| Malloc (total) (K) *        |       142 |       142 |       142 |       142 |       142 |       142 |       142 |        34 |
| Time (wall clock) (μs) *    |    112911 |    120062 |    145883 |    165675 |    173801 |    262554 |    262554 |        34 |

### GMSetzer GFM parse 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      8859 |      8863 |      8863 |      8863 |      8863 |      8863 |      8863 |       356 |
| Malloc (total) (K) *        |        14 |        14 |        14 |        14 |        14 |        14 |        14 |       356 |
| Time (wall clock) (μs) *    |     10175 |     10756 |     12960 |     14778 |     18891 |     32424 |     47410 |       356 |

### GMSetzer GFM parse 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       442 |       442 |       442 |       442 |       442 |       442 |       442 |         7 |
| Malloc (total) (K) *        |       712 |       712 |       712 |       712 |       712 |       712 |       712 |         7 |
| Time (wall clock) (μs) *    |    695747 |    717750 |    759693 |    800063 |    888401 |    888401 |    888401 |         7 |

### GMSetzer editor snapshot 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        68 |        68 |        68 |        68 |        68 |        68 |        68 |        29 |
| Malloc (total) (K) *        |       133 |       133 |       133 |       133 |       133 |       133 |       133 |        29 |
| Time (wall clock) (μs) *    |    126749 |    147980 |    167772 |    191103 |    233177 |    239866 |    239866 |        29 |

### GMSetzer editor snapshot 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6835 |      6836 |      6836 |      6836 |      6836 |      6836 |      6856 |       343 |
| Malloc (total) (K) *        |        13 |        13 |        13 |        13 |        13 |        13 |        13 |       343 |
| Time (wall clock) (μs) *    |     10111 |     10879 |     13443 |     16007 |     20480 |     35783 |     62485 |       343 |

### GMSetzer editor snapshot 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       346 |       346 |       346 |       346 |       346 |       346 |       346 |         6 |
| Malloc (total) (K) *        |       666 |       666 |       666 |       666 |       666 |       666 |       666 |         6 |
| Time (wall clock) (μs) *    |    725936 |    781189 |    839909 |    907018 |    947629 |    947629 |    947629 |         6 |

### GMSetzer inline syntax on 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        73 |        73 |        73 |        73 |        73 |        73 |        73 |        31 |
| Malloc (total) (K) *        |       192 |       192 |       192 |       192 |       192 |       192 |       192 |        31 |
| Time (wall clock) (μs) *    |    132556 |    149815 |    160825 |    173539 |    183239 |    211914 |    211914 |        31 |

### GMSetzer inline syntax on 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      7357 |      7361 |      7361 |      7361 |      7361 |      7361 |      7361 |       309 |
| Malloc (total) (K) *        |        19 |        19 |        19 |        19 |        19 |        19 |        19 |       309 |
| Time (wall clock) (μs) *    |     11461 |     12755 |     15598 |     17482 |     20234 |     36143 |     51308 |       309 |

### GMSetzer inline syntax on 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       378 |       378 |       378 |       378 |       378 |       378 |       378 |         6 |
| Malloc (total) (K) *        |       958 |       958 |       958 |       958 |       958 |       958 |       958 |         6 |
| Time (wall clock) (μs) *    |    743383 |    749208 |    812646 |    981991 |   1036388 |   1036388 |   1036388 |         6 |

### GMSetzer native analysis 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      4995 |      4995 |      4995 |      4995 |      4995 |      4995 |      4995 |       334 |
| Malloc (total) (K) *        |        18 |        18 |        18 |        18 |        18 |        18 |        18 |       334 |
| Time (wall clock) (μs) *    |     10114 |     11715 |     13566 |     16605 |     21742 |     29802 |     36820 |       334 |

### GMSetzer native analysis 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       516 |       516 |       516 |       516 |       516 |       516 |       516 |      3682 |
| Malloc (total) *            |      1882 |      1882 |      1882 |      1882 |      1882 |      1882 |      1882 |      3682 |
| Time (wall clock) (μs) *    |       691 |       905 |      1151 |      1440 |      1923 |      4887 |     14201 |      3682 |

### GMSetzer native analysis 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        30 |        30 |        30 |        30 |        30 |        30 |        30 |        70 |
| Malloc (total) (K) *        |        91 |        91 |        91 |        91 |        91 |        91 |        91 |        70 |
| Time (wall clock) (μs) *    |     54102 |     61604 |     69009 |     75629 |     93323 |    125984 |    125984 |        70 |

### GMSetzer outline 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       525 |       525 |       525 |       525 |       525 |       525 |       525 |      1393 |
| Malloc (total) *            |        17 |        17 |        17 |        17 |        17 |        17 |        17 |      1393 |
| Time (wall clock) (μs) *    |      2152 |      2863 |      3152 |      3899 |      4555 |      9585 |     16574 |      1393 |

### GMSetzer outline 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |        66 |        66 |        66 |        66 |        66 |        66 |        66 |     10000 |
| Malloc (total) *            |        14 |        14 |        14 |        14 |        14 |        14 |        14 |     10000 |
| Time (wall clock) (μs) *    |       106 |       149 |       158 |       210 |       340 |       577 |      5217 |     10000 |

### GMSetzer outline 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      4195 |      4195 |      4195 |      4195 |      4195 |      4195 |      4195 |       283 |
| Malloc (total) *            |        20 |        20 |        20 |        20 |        20 |        20 |        20 |       283 |
| Time (wall clock) (μs) *    |     13370 |     15000 |     17039 |     19235 |     21185 |     30540 |     35539 |       283 |

### GMSetzer parent index 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1869 |      1869 |      1869 |      1869 |      1869 |      1869 |      1869 |      1278 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |      1278 |
| Time (wall clock) (μs) *    |      2281 |      3164 |      3662 |      4106 |      5001 |      8462 |     30847 |      1278 |

### GMSetzer parent index 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       188 |       188 |       188 |       188 |       188 |       188 |       188 |     10000 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |     10000 |
| Time (wall clock) (μs) *    |       193 |       213 |       217 |       236 |       431 |       609 |     10121 |     10000 |

### GMSetzer parent index 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      9344 |      9344 |      9344 |      9344 |      9344 |      9344 |      9344 |       252 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |       252 |
| Time (wall clock) (μs) *    |     15740 |     17416 |     19153 |     20890 |     24068 |     34013 |     35825 |       252 |

### GMSetzer position index 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1750 |      1750 |      1750 |      1750 |      1750 |      1750 |      1750 |      2025 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |      2025 |
| Time (wall clock) (μs) *    |      1792 |      1938 |      2341 |      2691 |      3058 |      4870 |      7447 |      2025 |

### GMSetzer position index 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       176 |       176 |       176 |       176 |       176 |       176 |       176 |     10000 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |     10000 |
| Time (wall clock) (μs) *    |       170 |       174 |       175 |       193 |       321 |       705 |      1569 |     10000 |

### GMSetzer position index 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      8751 |      8751 |      8751 |      8751 |      8751 |      8751 |      8751 |       389 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |       389 |
| Time (wall clock) (μs) *    |      9770 |     10543 |     12165 |     13476 |     15540 |     26001 |     46827 |       389 |

### GMSetzer position index multibyte 1 MB (bytes: 1000192, corpus: multibyte-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1750 |      1750 |      1750 |      1750 |      1750 |      1750 |      1750 |       760 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |       760 |
| Time (wall clock) (μs) *    |      5497 |      5599 |      6128 |      7016 |      7971 |     13197 |     14780 |       760 |

### GMSetzer position index multibyte 100 KB (bytes: 100096, corpus: multibyte-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       175 |       175 |       175 |       175 |       175 |       175 |       175 |      7572 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |      7572 |
| Time (wall clock) (μs) *    |       530 |       537 |       549 |       701 |       842 |      1606 |      5144 |      7572 |

### GMSetzer position index multibyte 5 MB (bytes: 5000192, corpus: multibyte-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      8750 |      8750 |      8750 |      8750 |      8750 |      8750 |      8750 |       135 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |       135 |
| Time (wall clock) (μs) *    |     27805 |     31687 |     34341 |     38437 |     46989 |     76612 |    101405 |       135 |

### GMSetzer reference syntax off 1 MB (bytes: 1000098, corpus: references-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        39 |        39 |        39 |        39 |        39 |        39 |        39 |        42 |
| Malloc (total) (K) *        |       126 |       126 |       126 |       126 |       126 |       126 |       126 |        42 |
| Time (wall clock) (μs) *    |     85488 |     96666 |    109380 |    123208 |    142082 |    292777 |    292777 |        42 |

### GMSetzer reference syntax off 100 KB (bytes: 100188, corpus: references-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3892 |      3892 |      3892 |      3892 |      3892 |      3892 |      3892 |       425 |
| Malloc (total) (K) *        |        13 |        13 |        13 |        13 |        13 |        13 |        13 |       425 |
| Time (wall clock) (μs) *    |      7397 |      8962 |     10559 |     12919 |     16097 |     30212 |     46500 |       425 |

### GMSetzer reference syntax off 5 MB (bytes: 5000094, corpus: references-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       194 |       194 |       194 |       194 |       194 |       194 |       194 |         9 |
| Malloc (total) (K) *        |       631 |       631 |       631 |       631 |       631 |       631 |       631 |         9 |
| Time (wall clock) (μs) *    |    444439 |    569901 |    580387 |    611844 |    688062 |    688062 |    688062 |         9 |

### GMSetzer reference syntax on 1 MB (bytes: 1000098, corpus: references-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        62 |        62 |        62 |        62 |        62 |        62 |        62 |        36 |
| Malloc (total) (K) *        |       157 |       157 |       157 |       157 |       157 |       157 |       157 |        36 |
| Time (wall clock) (μs) *    |    102649 |    118555 |    128975 |    157155 |    194118 |    214966 |    214966 |        36 |

### GMSetzer reference syntax on 100 KB (bytes: 100188, corpus: references-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6749 |      6750 |      6750 |      6750 |      6750 |      6750 |      6750 |       331 |
| Malloc (total) (K) *        |        16 |        16 |        16 |        16 |        16 |        16 |        16 |       331 |
| Time (wall clock) (μs) *    |      9474 |     11477 |     13328 |     16155 |     21725 |     43188 |     61946 |       331 |

### GMSetzer reference syntax on 5 MB (bytes: 5000094, corpus: references-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       374 |       374 |       374 |       374 |       374 |       374 |       374 |         8 |
| Malloc (total) (K) *        |       783 |       783 |       783 |       783 |       783 |       783 |       783 |         8 |
| Time (wall clock) (μs) *    |    614701 |    616563 |    687866 |    730857 |    784629 |    784629 |    784629 |         8 |

### GMSetzer render 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        18 |        18 |        18 |        18 |        18 |        18 |        18 |        54 |
| Malloc (total) (K) *        |       206 |       206 |       206 |       206 |       206 |       206 |       206 |        54 |
| Time (wall clock) (μs) *    |     65176 |     68223 |     87556 |     94700 |    121045 |    241186 |    241186 |        54 |

### GMSetzer render 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1525 |      1525 |      1525 |      1525 |      1525 |      1525 |      1525 |       561 |
| Malloc (total) (K) *        |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       561 |
| Time (wall clock) (μs) *    |      6352 |      7303 |      8503 |      9519 |     11518 |     19169 |     22629 |       561 |

### GMSetzer render 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        83 |        83 |        83 |        83 |        83 |        83 |        83 |        13 |
| Malloc (total) (K) *        |      1031 |      1031 |      1031 |      1031 |      1031 |      1031 |      1031 |        13 |
| Time (wall clock) (μs) *    |    332018 |    385614 |    407896 |    432800 |    457441 |    573784 |    573784 |        13 |

### GMSetzer segment reconstruction 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5665 |      5665 |      5665 |      5665 |      5665 |      5665 |      5665 |       173 |
| Malloc (total) (K) *        |        95 |        95 |        95 |        95 |        95 |        95 |        95 |       173 |
| Time (wall clock) (μs) *    |     21783 |     22692 |     27132 |     30392 |     40010 |     59605 |     89155 |       173 |

### GMSetzer segment reconstruction 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       568 |       568 |       568 |       568 |       568 |       568 |       568 |      2024 |
| Malloc (total) *            |      9517 |      9517 |      9517 |      9517 |      9517 |      9517 |      9517 |      2024 |
| Time (wall clock) (μs) *    |      1630 |      1783 |      2080 |      2630 |      3660 |      7528 |     15210 |      2024 |

### GMSetzer segment reconstruction 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        28 |        28 |        28 |        28 |        28 |        28 |        28 |        31 |
| Malloc (total) (K) *        |       475 |       475 |       475 |       475 |       475 |       475 |       475 |        31 |
| Time (wall clock) (μs) *    |    120820 |    137363 |    157549 |    184156 |    215089 |    277876 |    277876 |        31 |

### GMSetzer selected inline parse 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        59 |        59 |        59 |        59 |        59 |        59 |        59 |        33 |
| Malloc (total) (K) *        |       119 |       119 |       119 |       119 |       119 |       119 |       119 |        33 |
| Time (wall clock) (μs) *    |    115239 |    135528 |    152961 |    165413 |    187695 |    195924 |    195924 |        33 |

### GMSetzer selected inline parse 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5902 |      5903 |      5903 |      5903 |      5903 |      5903 |      5903 |       399 |
| Malloc (total) (K) *        |        12 |        12 |        12 |        12 |        12 |        12 |        12 |       399 |
| Time (wall clock) (μs) *    |      8627 |      9470 |     11403 |     13435 |     17826 |     34537 |     48532 |       399 |

### GMSetzer selected inline parse 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       294 |       294 |       294 |       294 |       294 |       294 |       294 |         8 |
| Malloc (total) (K) *        |       593 |       593 |       593 |       593 |       593 |       593 |       593 |         8 |
| Time (wall clock) (μs) *    |    580998 |    601358 |    672137 |    687342 |    765092 |    765092 |    765092 |         8 |

### GMSetzer selected registry parse 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        59 |        59 |        59 |        59 |        59 |        59 |        59 |        32 |
| Malloc (total) (K) *        |       115 |       115 |       115 |       115 |       115 |       115 |       115 |        32 |
| Time (wall clock) (μs) *    |    119870 |    127074 |    156631 |    175636 |    194118 |    283663 |    283663 |        32 |

### GMSetzer selected registry parse 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5890 |      5894 |      5894 |      5894 |      5894 |      5894 |      5894 |       369 |
| Malloc (total) (K) *        |        12 |        12 |        12 |        12 |        12 |        12 |        12 |       369 |
| Time (wall clock) (μs) *    |      9647 |     10420 |     12845 |     14844 |     18645 |     27214 |     35514 |       369 |

### GMSetzer selected registry parse 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       294 |       294 |       294 |       294 |       294 |       294 |       294 |         7 |
| Malloc (total) (K) *        |       575 |       575 |       575 |       575 |       575 |       575 |       575 |         7 |
| Time (wall clock) (μs) *    |    587044 |    637534 |    707789 |    769655 |   1227140 |   1227140 |   1227140 |         7 |

### GMSetzer text reconstruction 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2102 |      2102 |      2102 |      2102 |      2102 |      2102 |      2102 |       676 |
| Malloc (total) (K) *        |        16 |        16 |        16 |        16 |        16 |        16 |        16 |       676 |
| Time (wall clock) (μs) *    |      4423 |      5669 |      6676 |      7811 |     10346 |     20873 |     34641 |       676 |

### GMSetzer text reconstruction 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       211 |       211 |       211 |       211 |       211 |       211 |       211 |     10000 |
| Malloc (total) *            |      1648 |      1648 |      1648 |      1648 |      1648 |      1648 |      1648 |     10000 |
| Time (wall clock) (μs) *    |       350 |       361 |       401 |       562 |       689 |      1297 |     22713 |     10000 |

### GMSetzer text reconstruction 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        11 |        11 |        11 |        11 |        11 |        11 |        11 |       135 |
| Malloc (total) (K) *        |        82 |        82 |        82 |        82 |        82 |        82 |        82 |       135 |
| Time (wall clock) (μs) *    |     27473 |     29606 |     36471 |     40272 |     47940 |     70910 |     77469 |       135 |

### GMSetzer validate 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       118 |       118 |       118 |       118 |       118 |       118 |       118 |       689 |
| Malloc (total) *            |         2 |         2 |         2 |         2 |         2 |         2 |         2 |       689 |
| Time (wall clock) (μs) *    |      4625 |      5792 |      6648 |      7844 |      9060 |     17826 |     23910 |       689 |

### GMSetzer validate 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      8510 |
| Malloc (total) *            |         2 |         2 |         2 |         2 |         2 |         2 |         2 |      8510 |
| Time (wall clock) (μs) *    |       256 |       347 |       424 |       678 |       936 |      2030 |     10631 |      8510 |

### GMSetzer validate 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       585 |       585 |       585 |       585 |       585 |       585 |       585 |       123 |
| Malloc (total) *            |         2 |         2 |         2 |         2 |         2 |         2 |         2 |       123 |
| Time (wall clock) (μs) *    |     27541 |     31801 |     36504 |     42009 |     59572 |    104530 |    120802 |       123 |

### Swift String UTF-16 count multibyte 1 MB (bytes: 1000192, corpus: multibyte-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1125 |      1125 |      1125 |      1125 |      1125 |      1125 |      1125 |       837 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |       837 |
| Time (wall clock) (μs) *    |      4538 |      4764 |      5661 |      6283 |      7270 |     13083 |     21121 |       837 |

### Swift String UTF-16 count multibyte 100 KB (bytes: 100096, corpus: multibyte-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       113 |       113 |       113 |       113 |       113 |       113 |       113 |      8928 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |      8928 |
| Time (wall clock) (μs) *    |       437 |       443 |       460 |       613 |       707 |      1031 |     36048 |      8928 |

### Swift String UTF-16 count multibyte 5 MB (bytes: 5000192, corpus: multibyte-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5625 |      5625 |      5625 |      5625 |      5625 |      5625 |      5625 |       187 |
| Malloc (total) *            |         4 |         4 |         4 |         4 |         4 |         4 |         4 |       187 |
| Time (wall clock) (μs) *    |     23380 |     23642 |     24379 |     28721 |     31998 |     58262 |     64351 |       187 |

### cmark-gfm (C) CommonMark parse 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        30 |        30 |        30 |        30 |        30 |        30 |        30 |        47 |
| Malloc (total) (K) *        |       224 |       224 |       224 |       224 |       224 |       224 |       224 |        47 |
| Time (wall clock) (μs) *    |     83073 |     84869 |     93913 |    107807 |    132252 |    284050 |    284050 |        47 |

### cmark-gfm (C) CommonMark parse 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2971 |      2971 |      2971 |      2971 |      2971 |      2971 |      2971 |       529 |
| Malloc (total) (K) *        |        23 |        23 |        23 |        23 |        23 |        23 |        23 |       529 |
| Time (wall clock) (μs) *    |      7512 |      8073 |      8405 |     10158 |     11829 |     18891 |     30680 |       529 |

### cmark-gfm (C) CommonMark parse 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       148 |       148 |       148 |       148 |       148 |       148 |       148 |        10 |
| Malloc (total) (K) *        |      1122 |      1122 |      1122 |      1122 |      1122 |      1122 |      1122 |        10 |
| Time (wall clock) (μs) *    |    423031 |    482869 |    508297 |    537395 |    570425 |    616908 |    616908 |        10 |

### cmark-gfm (C) GFM parse 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        39 |        39 |        39 |        39 |        39 |        39 |        39 |        25 |
| Malloc (total) (K) *        |       431 |       431 |       431 |       431 |       431 |       431 |       431 |        25 |
| Time (wall clock) (μs) *    |    152969 |    170918 |    201064 |    216269 |    288621 |    325489 |    325489 |        25 |

### cmark-gfm (C) GFM parse 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3878 |      3878 |      3878 |      3878 |      3878 |      3878 |      3878 |       245 |
| Malloc (total) (K) *        |        43 |        43 |        43 |        43 |        43 |        43 |        43 |       245 |
| Time (wall clock) (μs) *    |     15168 |     17727 |     20070 |     21987 |     24314 |     37388 |     44180 |       245 |

### cmark-gfm (C) GFM parse 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       193 |       193 |       193 |       193 |       193 |       193 |       193 |         5 |
| Malloc (total) (K) *        |      2154 |      2154 |      2154 |      2154 |      2154 |      2154 |      2154 |         5 |
| Time (wall clock) (μs) *    |    793004 |   1031799 |   1032847 |   1065353 |   1477210 |   1477210 |   1477210 |         5 |

### cmark-gfm (C) references 1 MB (bytes: 1000098, corpus: references-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        15 |        15 |        15 |        15 |        15 |        15 |        15 |        57 |
| Malloc (total) (K) *        |       162 |       162 |       162 |       162 |       162 |       162 |       162 |        57 |
| Time (wall clock) (μs) *    |     66062 |     75039 |     85197 |     98107 |    119669 |    181987 |    181987 |        57 |

### cmark-gfm (C) references 100 KB (bytes: 100188, corpus: references-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1518 |      1518 |      1518 |      1518 |      1518 |      1518 |      1518 |       557 |
| Malloc (total) (K) *        |        16 |        16 |        16 |        16 |        16 |        16 |        16 |       557 |
| Time (wall clock) (μs) *    |      4808 |      7197 |      8352 |      9642 |     11813 |     21709 |     43601 |       557 |

### cmark-gfm (C) references 5 MB (bytes: 5000094, corpus: references-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        76 |        76 |        76 |        76 |        76 |        76 |        76 |        12 |
| Malloc (total) (K) *        |       808 |       808 |       808 |       808 |       808 |       808 |       808 |        12 |
| Time (wall clock) (μs) *    |    351427 |    383517 |    428343 |    447218 |    569377 |    625638 |    625638 |        12 |

### swift-markdown parse 1 MB (bytes: 1000100, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        67 |        67 |        67 |        67 |        67 |        67 |        67 |        11 |
| Malloc (total) (K) *        |       668 |       668 |       668 |       668 |       668 |       668 |       668 |        11 |
| Time (wall clock) (μs) *    |    402028 |    435683 |    459538 |    471859 |    477626 |    599900 |    599900 |        11 |

### swift-markdown parse 100 KB (bytes: 100284, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6672 |      6676 |      6676 |      6676 |      6676 |      6685 |      6689 |       107 |
| Malloc (total) (K) *        |        67 |        67 |        67 |        67 |        67 |        67 |        67 |       107 |
| Time (wall clock) (μs) *    |     32925 |     39911 |     45122 |     49742 |     59998 |     91619 |    117428 |       107 |

### swift-markdown parse 5 MB (bytes: 5000500, corpus: mixed-v1)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       333 |       333 |       333 |       333 |       333 |       333 |       333 |         3 |
| Malloc (total) (K) *        |      3340 |      3340 |      3340 |      3340 |      3340 |      3340 |      3340 |         3 |
| Time (wall clock) (μs) *    |   2066948 |   2067792 |   2355102 |   2480704 |   2480704 |   2480704 |   2480704 |         3 |

