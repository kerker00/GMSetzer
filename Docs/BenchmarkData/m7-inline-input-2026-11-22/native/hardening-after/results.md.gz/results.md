
## Baseline 'Current_run'

```
Host 'PowerG5' with 4 'x86_64' processors with 31 GB memory, running:
#1 SMP PREEMPT_DYNAMIC Fri, 13 Nov 2026 19:45:18 +0000
```
## HardeningBenchmarks

### GMSetzer footnotes-repeated-v1 parse syntax-off 16 KiB (bytes: 16398, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3197 |      3198 |      3198 |      3198 |      3198 |      3198 |      3198 |      1163 |
| Malloc (total) (K) *        |        12 |        12 |        12 |        12 |        12 |        12 |        12 |      1163 |
| Time (wall clock) (μs) *    |      3844 |      4252 |      4289 |      4321 |      4379 |      4788 |      5960 |      1163 |

### GMSetzer footnotes-repeated-v1 parse syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        58 |        58 |        58 |        58 |        58 |        58 |        58 |        74 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        74 |
| Time (wall clock) (μs) *    |     67257 |     67764 |     67961 |     68354 |     69140 |     72541 |     72541 |        74 |

### GMSetzer footnotes-repeated-v1 parse syntax-off 64 KiB (bytes: 65538, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        14 |        14 |        14 |        14 |        14 |        14 |        14 |       297 |
| Malloc (total) (K) *        |        46 |        46 |        46 |        46 |        46 |        46 |        46 |       297 |
| Time (wall clock) (μs) *    |     15775 |     16736 |     16810 |     16908 |     17121 |     18416 |     18586 |       297 |

### GMSetzer footnotes-repeated-v1 parse syntax-on 16 KiB (bytes: 16398, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3854 |      3854 |      3854 |      3854 |      3854 |      3854 |      3855 |       944 |
| Malloc (total) (K) *        |        12 |        12 |        12 |        12 |        12 |        12 |        12 |       944 |
| Time (wall clock) (μs) *    |      5077 |      5214 |      5272 |      5345 |      5439 |      6005 |      7065 |       944 |

### GMSetzer footnotes-repeated-v1 parse syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        69 |        69 |        69 |        69 |        69 |        69 |        69 |        64 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        64 |
| Time (wall clock) (μs) *    |     78130 |     78840 |     79102 |     79561 |     80413 |     82585 |     82585 |        64 |

### GMSetzer footnotes-repeated-v1 parse syntax-on 64 KiB (bytes: 65538, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        17 |        17 |        17 |        17 |        17 |        17 |        17 |       261 |
| Malloc (total) (K) *        |        46 |        46 |        46 |        46 |        46 |        46 |        46 |       261 |
| Time (wall clock) (μs) *    |     18003 |     19104 |     19218 |     19333 |     19464 |     21185 |     22334 |       261 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-off 16 KiB (bytes: 16398, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5333 |      5337 |      5337 |      5337 |      5337 |      5337 |      5344 |       695 |
| Malloc (total) (K) *        |        17 |        17 |        17 |        17 |        17 |        17 |        17 |       695 |
| Time (wall clock) (μs) *    |      6662 |      7094 |      7156 |      7250 |      7373 |      8208 |      9029 |       695 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        92 |        92 |        92 |        92 |        92 |        92 |        92 |        43 |
| Malloc (total) (K) *        |       271 |       271 |       271 |       271 |       271 |       271 |       271 |        43 |
| Time (wall clock) (μs) *    |    114889 |    116392 |    117768 |    118489 |    119079 |    119648 |    119648 |        43 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-off 64 KiB (bytes: 65538, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        23 |        23 |        23 |        23 |        23 |        23 |        23 |       176 |
| Malloc (total) (K) *        |        68 |        68 |        68 |        68 |        68 |        68 |        68 |       176 |
| Time (wall clock) (μs) *    |     27686 |     28246 |     28410 |     28590 |     28967 |     30163 |     30279 |       176 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 16 KiB (bytes: 16398, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5990 |      5992 |      5992 |      5992 |      5992 |      5997 |      6000 |       691 |
| Malloc (total) (K) *        |        17 |        17 |        17 |        17 |        17 |        17 |        17 |       691 |
| Time (wall clock) (μs) *    |      7042 |      7156 |      7201 |      7270 |      7352 |      8081 |      9469 |       691 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       103 |       103 |       103 |       103 |       103 |       103 |       103 |        39 |
| Malloc (total) (K) *        |       271 |       271 |       271 |       271 |       271 |       271 |       271 |        39 |
| Time (wall clock) (μs) *    |    128628 |    130548 |    131006 |    132055 |    134087 |    135343 |    135343 |        39 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 64 KiB (bytes: 65538, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        25 |        25 |        25 |        25 |        25 |        25 |        25 |       167 |
| Malloc (total) (K) *        |        68 |        68 |        68 |        68 |        68 |        68 |        68 |       167 |
| Time (wall clock) (μs) *    |     29624 |     29835 |     29934 |     30048 |     30409 |     31916 |     32116 |       167 |

### GMSetzer invalid-utf8-v1 parse syntax-off 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      5816 |
| Malloc (total) *            |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      5816 |
| Time (wall clock) (μs) *    |       836 |       842 |       843 |       868 |       887 |       980 |      2449 |      5816 |

### GMSetzer invalid-utf8-v1 parse syntax-off 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       340 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       340 |
| Time (wall clock) (μs) *    |     14532 |     14590 |     14631 |     14713 |     14950 |     16220 |     17279 |       340 |

### GMSetzer invalid-utf8-v1 parse syntax-off 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      1267 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      1267 |
| Time (wall clock) (μs) *    |      3832 |      3885 |      3942 |      3969 |      4024 |      4477 |      5644 |      1267 |

### GMSetzer invalid-utf8-v1 parse syntax-on 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      5792 |
| Malloc (total) *            |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      5792 |
| Time (wall clock) (μs) *    |       838 |       844 |       845 |       870 |       888 |      1013 |      2606 |      5792 |

### GMSetzer invalid-utf8-v1 parse syntax-on 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       341 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       341 |
| Time (wall clock) (μs) *    |     14531 |     14590 |     14631 |     14688 |     14778 |     16171 |     17272 |       341 |

### GMSetzer invalid-utf8-v1 parse syntax-on 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      1268 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      1268 |
| Time (wall clock) (μs) *    |      3834 |      3881 |      3934 |      3961 |      4010 |      4551 |      6013 |      1268 |

### GMSetzer long-emphasis-v1 parse syntax-off 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2108 |      2108 |      2108 |      2108 |      2108 |      2108 |      2108 |      4670 |
| Malloc (total) *            |        30 |        30 |        30 |        30 |        30 |        30 |        30 |      4670 |
| Time (wall clock) (μs) *    |       934 |      1047 |      1051 |      1078 |      1105 |      1231 |      2689 |      4670 |

### GMSetzer long-emphasis-v1 parse syntax-off 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        41 |        41 |        41 |        41 |        41 |        41 |        41 |       446 |
| Malloc (total) *            |        34 |        34 |        34 |        34 |        34 |        34 |        34 |       446 |
| Time (wall clock) (μs) *    |     10667 |     11125 |     11166 |     11215 |     11354 |     12763 |     14428 |       446 |

### GMSetzer long-emphasis-v1 parse syntax-off 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      9887 |      9887 |      9887 |      9887 |      9887 |      9887 |      9887 |      2363 |
| Malloc (total) *            |        32 |        32 |        32 |        32 |        32 |        32 |        32 |      2363 |
| Time (wall clock) (μs) *    |      2073 |      2084 |      2091 |      2109 |      2154 |      2466 |      4528 |      2363 |

### GMSetzer long-emphasis-v1 parse syntax-on 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3420 |      3420 |      3420 |      3420 |      3420 |      3420 |      3420 |      2994 |
| Malloc (total) *            |        60 |        60 |        60 |        60 |        60 |        60 |        60 |      2994 |
| Time (wall clock) (μs) *    |      1138 |      1633 |      1642 |      1679 |      1721 |      1943 |      3531 |      2994 |

### GMSetzer long-emphasis-v1 parse syntax-on 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        62 |        62 |        62 |        62 |        62 |        62 |        62 |       271 |
| Malloc (total) *            |        72 |        72 |        72 |        72 |        72 |        72 |        72 |       271 |
| Time (wall clock) (μs) *    |     18228 |     18350 |     18416 |     18514 |     18743 |     20103 |     21041 |       271 |

### GMSetzer long-emphasis-v1 parse syntax-on 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        15 |        15 |        15 |        15 |        15 |        15 |        15 |      1006 |
| Malloc (total) *            |        66 |        66 |        66 |        66 |        66 |        66 |        66 |      1006 |
| Time (wall clock) (μs) *    |      4875 |      4923 |      4940 |      4973 |      5026 |      5562 |      6990 |      1006 |

### GMSetzer m5-composed-v1 parse syntax-off 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      4247 |      4276 |      4279 |      4279 |      4279 |      4279 |      4279 |       903 |
| Malloc (total) (K) *        |        18 |        18 |        18 |        18 |        18 |        19 |        19 |       903 |
| Time (wall clock) (μs) *    |      5382 |      5452 |      5497 |      5566 |      5648 |      6238 |      8053 |       903 |

### GMSetzer m5-composed-v1 parse syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        66 |        66 |        66 |        66 |        66 |        66 |        66 |        58 |
| Malloc (total) (K) *        |       283 |       284 |       284 |       284 |       284 |       284 |       284 |        58 |
| Time (wall clock) (μs) *    |     85055 |     85393 |     86180 |     89063 |     91095 |     97818 |     97818 |        58 |

### GMSetzer m5-composed-v1 parse syntax-off 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        17 |        17 |        17 |        17 |        17 |        17 |        17 |       246 |
| Malloc (total) (K) *        |        71 |        71 |        72 |        72 |        72 |        72 |        72 |       246 |
| Time (wall clock) (μs) *    |     19846 |     20021 |     20103 |     20267 |     20759 |     24265 |     26033 |       246 |

### GMSetzer m5-composed-v1 parse syntax-on 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6238 |      6255 |      6258 |      6258 |      6258 |      6258 |      6258 |       545 |
| Malloc (total) (K) *        |        19 |        19 |        19 |        19 |        19 |        19 |        19 |       545 |
| Time (wall clock) (μs) *    |      8620 |      9028 |      9134 |      9232 |      9380 |     10559 |     12264 |       545 |

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        98 |        98 |        98 |        98 |        98 |        98 |        98 |        35 |
| Malloc (total) (K) *        |       285 |       285 |       286 |       286 |       286 |       286 |       286 |        35 |
| Time (wall clock) (μs) *    |    143492 |    144572 |    144966 |    146145 |    147194 |    152792 |    152792 |        35 |

### GMSetzer m5-composed-v1 parse syntax-on 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        25 |        25 |        25 |        25 |        25 |        25 |        25 |       144 |
| Malloc (total) (K) *        |        72 |        72 |        72 |        72 |        72 |        72 |        72 |       144 |
| Time (wall clock) (μs) *    |     34303 |     34669 |     34734 |     34898 |     35357 |     37585 |     38668 |       144 |

### GMSetzer m5-composed-v1 parse-render syntax-off 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5125 |      5140 |      5145 |      5145 |      5149 |      5153 |      5153 |       702 |
| Malloc (total) (K) *        |        26 |        27 |        27 |        27 |        27 |        27 |        27 |       702 |
| Time (wall clock) (μs) *    |      6916 |      7016 |      7078 |      7160 |      7274 |      7954 |      9414 |       702 |

### GMSetzer m5-composed-v1 parse-render syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        80 |        80 |        80 |        80 |        80 |        80 |        80 |        45 |
| Malloc (total) (K) *        |       405 |       406 |       406 |       406 |       406 |       406 |       406 |        45 |
| Time (wall clock) (μs) *    |    109524 |    111149 |    111673 |    112460 |    114033 |    117445 |    117445 |        45 |

### GMSetzer m5-composed-v1 parse-render syntax-off 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        20 |        20 |        20 |        20 |        20 |        20 |        20 |       189 |
| Malloc (total) (K) *        |       102 |       102 |       103 |       103 |       103 |       103 |       103 |       189 |
| Time (wall clock) (μs) *    |     25814 |     26247 |     26395 |     26542 |     26722 |     28803 |     28833 |       189 |

### GMSetzer m5-composed-v1 parse-render syntax-on 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      7105 |      7123 |      7123 |      7123 |      7124 |      7124 |      7124 |       466 |
| Malloc (total) (K) *        |        27 |        27 |        27 |        27 |        27 |        27 |        27 |       466 |
| Time (wall clock) (μs) *    |     10349 |     10592 |     10682 |     10789 |     10928 |     12190 |     13462 |       466 |

### GMSetzer m5-composed-v1 parse-render syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       111 |       111 |       111 |       111 |       111 |       111 |       111 |        29 |
| Malloc (total) (K) *        |       410 |       411 |       412 |       412 |       412 |       412 |       412 |        29 |
| Time (wall clock) (μs) *    |    171738 |    172753 |    173408 |    174326 |    175374 |    180620 |    180620 |        29 |

### GMSetzer m5-composed-v1 parse-render syntax-on 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        28 |        28 |        28 |        28 |        28 |        28 |        28 |       120 |
| Malloc (total) (K) *        |       104 |       104 |       104 |       104 |       104 |       104 |       104 |       120 |
| Time (wall clock) (μs) *    |     40735 |     41452 |     41615 |     41878 |     42959 |     48398 |     51478 |       120 |

### GMSetzer open-brackets-v1 parse syntax-off 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6642 |      6642 |      6642 |      6642 |      6642 |      6642 |      6642 |      1313 |
| Malloc (total) *            |        43 |        43 |        43 |        43 |        43 |        43 |        43 |      1313 |
| Time (wall clock) (μs) *    |      3556 |      3762 |      3785 |      3815 |      3869 |      4440 |      5895 |      1313 |

### GMSetzer open-brackets-v1 parse syntax-off 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       114 |       114 |       114 |       114 |       114 |       114 |       114 |       127 |
| Malloc (total) *            |        51 |        51 |        51 |        51 |        51 |        51 |        51 |       127 |
| Time (wall clock) (μs) *    |     39105 |     39256 |     39354 |     39551 |     40010 |     41484 |     44100 |       127 |

### GMSetzer open-brackets-v1 parse syntax-off 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        28 |        28 |        28 |        28 |        28 |        28 |        28 |       450 |
| Malloc (total) *            |        47 |        47 |        47 |        47 |        47 |        47 |        47 |       450 |
| Time (wall clock) (μs) *    |     10969 |     11035 |     11076 |     11125 |     11231 |     12542 |     12798 |       450 |

### GMSetzer open-brackets-v1 parse syntax-on 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6642 |      6642 |      6642 |      6642 |      6642 |      6642 |      6642 |      1329 |
| Malloc (total) *            |        43 |        43 |        43 |        43 |        43 |        43 |        43 |      1329 |
| Time (wall clock) (μs) *    |      3668 |      3705 |      3725 |      3768 |      3838 |      4338 |      5484 |      1329 |

### GMSetzer open-brackets-v1 parse syntax-on 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       114 |       114 |       114 |       114 |       114 |       114 |       114 |       124 |
| Malloc (total) *            |        51 |        51 |        51 |        51 |        51 |        51 |        51 |       124 |
| Time (wall clock) (μs) *    |     40008 |     40174 |     40272 |     40468 |     40796 |     42762 |     44864 |       124 |

### GMSetzer open-brackets-v1 parse syntax-on 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        28 |        28 |        28 |        28 |        28 |        28 |        28 |       432 |
| Malloc (total) *            |        47 |        47 |        47 |        47 |        47 |        47 |        47 |       432 |
| Time (wall clock) (μs) *    |     11429 |     11493 |     11534 |     11583 |     11690 |     12960 |     13153 |       432 |

### GMSetzer quote-overflow-v1 parse syntax-off 16 KiB (bytes: 16576, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3657 |      3657 |      3657 |      3657 |      3657 |      3657 |      3657 |      5691 |
| Malloc (total) *            |        85 |        85 |        85 |        85 |        85 |        85 |        85 |      5691 |
| Time (wall clock) (μs) *    |       852 |       860 |       861 |       886 |       904 |       991 |      2501 |      5691 |

### GMSetzer quote-overflow-v1 parse syntax-off 256 KiB (bytes: 262626, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        57 |        57 |        57 |        57 |        57 |        57 |        57 |       303 |
| Malloc (total) *            |       571 |       571 |       571 |       571 |       571 |       571 |       571 |       303 |
| Time (wall clock) (μs) *    |     16278 |     16392 |     16441 |     16531 |     16638 |     18006 |     20663 |       303 |

### GMSetzer quote-overflow-v1 parse syntax-off 64 KiB (bytes: 65786, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        14 |        14 |        14 |        14 |        14 |        14 |        14 |      1316 |
| Malloc (total) *            |       185 |       185 |       185 |       185 |       185 |       185 |       185 |      1316 |
| Time (wall clock) (μs) *    |      3709 |      3742 |      3760 |      3805 |      3879 |      4399 |      6124 |      1316 |

### GMSetzer quote-overflow-v1 parse syntax-on 16 KiB (bytes: 16576, corpus: quote-overflow-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      4313 |      4313 |      4313 |      4313 |      4313 |      4313 |      4313 |      2767 |
| Malloc (total) *            |       111 |       111 |       111 |       111 |       111 |       111 |       111 |      2767 |
| Time (wall clock) (μs) *    |      1755 |      1764 |      1794 |      1818 |      1860 |      2006 |      3820 |      2767 |

### GMSetzer quote-overflow-v1 parse syntax-on 256 KiB (bytes: 262626, corpus: quote-overflow-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        68 |        68 |        68 |        68 |        68 |        68 |        68 |       227 |
| Malloc (total) *            |       605 |       605 |       605 |       605 |       605 |       605 |       605 |       227 |
| Time (wall clock) (μs) *    |     21779 |     21905 |     21955 |     22036 |     22331 |     23544 |     24150 |       227 |

### GMSetzer quote-overflow-v1 parse syntax-on 64 KiB (bytes: 65786, corpus: quote-overflow-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        17 |        17 |        17 |        17 |        17 |        17 |        17 |       857 |
| Malloc (total) *            |       215 |       215 |       215 |       215 |       215 |       215 |       215 |       857 |
| Time (wall clock) (μs) *    |      5715 |      5763 |      5792 |      5845 |      5935 |      6554 |      7913 |       857 |

### GMSetzer unmatched-backticks-v1 parse syntax-off 16 KiB (bytes: 16476, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       631 |       631 |       631 |       631 |       631 |       631 |       631 |     10000 |
| Malloc (total) *            |       387 |       387 |       387 |       387 |       387 |       387 |       387 |     10000 |
| Time (wall clock) (μs) *    |       147 |       148 |       148 |       151 |       155 |       203 |      1751 |     10000 |

### GMSetzer unmatched-backticks-v1 parse syntax-off 256 KiB (bytes: 262455, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1624 |      1624 |      1624 |      1624 |      1624 |      1624 |      1624 |      3692 |
| Malloc (total) *            |      1477 |      1477 |      1477 |      1477 |      1477 |      1477 |      1477 |      3692 |
| Time (wall clock) (μs) *    |      1310 |      1320 |      1348 |      1361 |      1394 |      1512 |      2809 |      3692 |

### GMSetzer unmatched-backticks-v1 parse syntax-off 64 KiB (bytes: 65708, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       864 |       864 |       864 |       864 |       864 |       864 |       864 |     10000 |
| Malloc (total) *            |       751 |       751 |       751 |       751 |       751 |       751 |       751 |     10000 |
| Time (wall clock) (μs) *    |       361 |       365 |       366 |       372 |       394 |       470 |      2302 |     10000 |

### GMSetzer unmatched-backticks-v1 parse syntax-on 16 KiB (bytes: 16476, corpus: unmatched-backticks-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       631 |       631 |       631 |       631 |       631 |       631 |       631 |     10000 |
| Malloc (total) *            |       387 |       387 |       387 |       387 |       387 |       387 |       387 |     10000 |
| Time (wall clock) (μs) *    |       150 |       153 |       153 |       157 |       163 |       213 |       352 |     10000 |

### GMSetzer unmatched-backticks-v1 parse syntax-on 256 KiB (bytes: 262455, corpus: unmatched-backticks-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1624 |      1624 |      1624 |      1624 |      1624 |      1624 |      1624 |      3669 |
| Malloc (total) *            |      1477 |      1477 |      1477 |      1477 |      1477 |      1477 |      1477 |      3669 |
| Time (wall clock) (μs) *    |      1316 |      1327 |      1356 |      1368 |      1400 |      1567 |      2889 |      3669 |

### GMSetzer unmatched-backticks-v1 parse syntax-on 64 KiB (bytes: 65708, corpus: unmatched-backticks-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       864 |       864 |       864 |       864 |       864 |       864 |       864 |     10000 |
| Malloc (total) *            |       751 |       751 |       751 |       751 |       751 |       751 |       751 |     10000 |
| Time (wall clock) (μs) *    |       363 |       367 |       369 |       377 |       396 |       464 |      2368 |     10000 |

### cmark-gfm (C) invalid-utf8-v1 parse 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       574 |       574 |       574 |       574 |       574 |       574 |       574 |     10000 |
| Malloc (total) *            |      2757 |      2757 |      2757 |      2757 |      2757 |      2757 |      2757 |     10000 |
| Time (wall clock) (μs) *    |       316 |       318 |       321 |       327 |       341 |       410 |      1842 |     10000 |

### cmark-gfm (C) invalid-utf8-v1 parse 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      9249 |      9249 |      9249 |      9249 |      9249 |      9249 |      9249 |       858 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       858 |
| Time (wall clock) (μs) *    |      5722 |      5759 |      5779 |      5829 |      5906 |      6660 |      8853 |       858 |

### cmark-gfm (C) invalid-utf8-v1 parse 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2250 |      2250 |      2250 |      2250 |      2250 |      2250 |      2250 |      3828 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      3828 |
| Time (wall clock) (μs) *    |      1268 |      1276 |      1283 |      1316 |      1349 |      1492 |      2845 |      3828 |

### cmark-gfm (C) long-emphasis-v1 parse 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       806 |       806 |       806 |       806 |       806 |       806 |       806 |     10000 |
| Malloc (total) *            |      4119 |      4119 |      4119 |      4119 |      4119 |      4119 |      4119 |     10000 |
| Time (wall clock) (μs) *    |       450 |       453 |       455 |       465 |       484 |       561 |      2287 |     10000 |

### cmark-gfm (C) long-emphasis-v1 parse 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        13 |        13 |        13 |        13 |        13 |        13 |        13 |       489 |
| Malloc (total) (K) *        |        66 |        66 |        66 |        66 |        66 |        66 |        66 |       489 |
| Time (wall clock) (μs) *    |      9864 |      9994 |     10076 |     10535 |     10715 |     11977 |     12442 |       489 |

### cmark-gfm (C) long-emphasis-v1 parse 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3214 |      3214 |      3214 |      3214 |      3214 |      3214 |      3214 |      2505 |
| Malloc (total) (K) *        |        16 |        16 |        16 |        16 |        16 |        16 |        16 |      2505 |
| Time (wall clock) (μs) *    |      1880 |      1901 |      1916 |      1975 |      2286 |      2505 |      4268 |      2505 |

### cmark-gfm (C) open-brackets-v1 parse 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3672 |      3672 |      3672 |      3672 |      3672 |      3672 |      3672 |      2068 |
| Malloc (total) (K) *        |        33 |        33 |        33 |        33 |        33 |        33 |        33 |      2068 |
| Time (wall clock) (μs) *    |      2367 |      2390 |      2396 |      2410 |      2456 |      2773 |      3987 |      2068 |

### cmark-gfm (C) open-brackets-v1 parse 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        59 |        59 |        59 |        59 |        59 |        59 |        59 |       118 |
| Malloc (total) (K) *        |       524 |       524 |       524 |       524 |       524 |       524 |       524 |       118 |
| Time (wall clock) (μs) *    |     41800 |     42074 |     42205 |     42631 |     43024 |     44499 |     45628 |       118 |

### cmark-gfm (C) open-brackets-v1 parse 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        15 |        15 |        15 |        15 |        15 |        15 |        15 |       472 |
| Malloc (total) (K) *        |       131 |       131 |       131 |       131 |       131 |       131 |       131 |       472 |
| Time (wall clock) (μs) *    |     10344 |     10428 |     10469 |     10559 |     10830 |     12657 |     13571 |       472 |

### cmark-gfm (C) quote-overflow-v1 parse 16 KiB (bytes: 16576, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1982 |      1982 |      1982 |      1982 |      1982 |      1982 |      1982 |      3800 |
| Malloc (total) (K) *        |        16 |        16 |        16 |        16 |        16 |        16 |        16 |      3800 |
| Time (wall clock) (μs) *    |      1275 |      1285 |      1299 |      1324 |      1355 |      1473 |      2819 |      3800 |

### cmark-gfm (C) quote-overflow-v1 parse 256 KiB (bytes: 262626, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        31 |        31 |        31 |        31 |        31 |        31 |        31 |       182 |
| Malloc (total) (K) *        |       261 |       261 |       261 |       261 |       261 |       261 |       261 |       182 |
| Time (wall clock) (μs) *    |     26769 |     27034 |     27378 |     28017 |     28197 |     29540 |     30107 |       182 |

### cmark-gfm (C) quote-overflow-v1 parse 64 KiB (bytes: 65786, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      7859 |      7859 |      7859 |      7859 |      7859 |      7859 |      7859 |       764 |
| Malloc (total) (K) *        |        65 |        65 |        65 |        65 |        65 |        65 |        65 |       764 |
| Time (wall clock) (μs) *    |      6293 |      6463 |      6513 |      6578 |      6660 |      7258 |      8456 |       764 |

### cmark-gfm (C) unmatched-backticks-v1 parse 16 KiB (bytes: 16476, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       197 |       197 |       197 |       197 |       197 |       197 |       197 |     10000 |
| Malloc (total) *            |       393 |       393 |       393 |       393 |       393 |       393 |       393 |     10000 |
| Time (wall clock) (μs) *    |        65 |        67 |        67 |        69 |        70 |       104 |       224 |     10000 |

### cmark-gfm (C) unmatched-backticks-v1 parse 256 KiB (bytes: 262455, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2420 |      2420 |      2420 |      2420 |      2420 |      2420 |      2420 |      3912 |
| Malloc (total) *            |      1486 |      1486 |      1486 |      1486 |      1486 |      1486 |      1486 |      3912 |
| Time (wall clock) (μs) *    |       901 |      1248 |      1274 |      1281 |      1307 |      1444 |      3139 |      3912 |

### cmark-gfm (C) unmatched-backticks-v1 parse 64 KiB (bytes: 65708, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       715 |       715 |       715 |       715 |       715 |       715 |       715 |     10000 |
| Malloc (total) *            |       759 |       759 |       759 |       759 |       759 |       759 |       759 |     10000 |
| Time (wall clock) (μs) *    |       203 |       211 |       214 |       217 |       222 |       275 |      1713 |     10000 |

