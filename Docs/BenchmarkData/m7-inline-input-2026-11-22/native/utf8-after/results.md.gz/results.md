
## Baseline 'Current_run'

```
Host 'PowerG5' with 4 'x86_64' processors with 31 GB memory, running:
#1 SMP PREEMPT_DYNAMIC Fri, 13 Nov 2026 19:45:18 +0000
```
## UTF8Benchmarks

### GMSetzer invalid-compatible-v1 parse syntax-off 16 KiB (bytes: 16385, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1538 |      1538 |      1538 |      1538 |      1538 |      1538 |      1538 |      4084 |
| Malloc (total) *            |      3285 |      3285 |      3285 |      3285 |      3285 |      3285 |      3285 |      4084 |
| Time (wall clock) (μs) *    |      1179 |      1214 |      1217 |      1221 |      1243 |      1398 |      3085 |      4084 |

### GMSetzer invalid-compatible-v1 parse syntax-off 256 KiB (bytes: 262145, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        25 |        25 |        25 |        25 |        25 |        25 |        25 |       338 |
| Malloc (total) (K) *        |        52 |        52 |        52 |        52 |        52 |        52 |        52 |       338 |
| Time (wall clock) (μs) *    |     14599 |     14672 |     14713 |     14787 |     15016 |     16499 |     18065 |       338 |

### GMSetzer invalid-compatible-v1 parse syntax-off 64 KiB (bytes: 65545, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6150 |      6150 |      6150 |      6150 |      6150 |      6150 |      6150 |      1341 |
| Malloc (total) (K) *        |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      1341 |
| Time (wall clock) (μs) *    |      3670 |      3688 |      3697 |      3717 |      3770 |      4252 |      5355 |      1341 |

### GMSetzer invalid-compatible-v1 parse syntax-on 16 KiB (bytes: 16385, corpus: invalid-compatible-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1538 |      1538 |      1538 |      1538 |      1538 |      1538 |      1538 |      4117 |
| Malloc (total) *            |      3285 |      3285 |      3285 |      3285 |      3285 |      3285 |      3285 |      4117 |
| Time (wall clock) (μs) *    |      1177 |      1185 |      1212 |      1221 |      1242 |      1372 |      2783 |      4117 |

### GMSetzer invalid-compatible-v1 parse syntax-on 256 KiB (bytes: 262145, corpus: invalid-compatible-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        25 |        25 |        25 |        25 |        25 |        25 |        25 |       339 |
| Malloc (total) (K) *        |        52 |        52 |        52 |        52 |        52 |        52 |        52 |       339 |
| Time (wall clock) (μs) *    |     14550 |     14647 |     14721 |     14819 |     14934 |     16302 |     16907 |       339 |

### GMSetzer invalid-compatible-v1 parse syntax-on 64 KiB (bytes: 65545, corpus: invalid-compatible-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6150 |      6150 |      6150 |      6150 |      6150 |      6150 |      6150 |      1340 |
| Malloc (total) (K) *        |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      1340 |
| Time (wall clock) (μs) *    |      3668 |      3686 |      3695 |      3721 |      3797 |      4252 |      5256 |      1340 |

### GMSetzer invalid-utf8-v1 parse syntax-off 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      4258 |
| Malloc (total) *            |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      4258 |
| Time (wall clock) (μs) *    |      1137 |      1144 |      1171 |      1179 |      1205 |      1345 |      2763 |      4258 |

### GMSetzer invalid-utf8-v1 parse syntax-off 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       337 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       337 |
| Time (wall clock) (μs) *    |     14656 |     14729 |     14787 |     14877 |     15024 |     16777 |     17397 |       337 |

### GMSetzer invalid-utf8-v1 parse syntax-off 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      1258 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      1258 |
| Time (wall clock) (μs) *    |      3861 |      3914 |      3959 |      3992 |      4049 |      4547 |      5559 |      1258 |

### GMSetzer invalid-utf8-v1 parse syntax-on 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      4243 |
| Malloc (total) *            |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      4243 |
| Time (wall clock) (μs) *    |      1138 |      1146 |      1174 |      1179 |      1208 |      1347 |      2644 |      4243 |

### GMSetzer invalid-utf8-v1 parse syntax-on 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       338 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       338 |
| Time (wall clock) (μs) *    |     14658 |     14721 |     14762 |     14819 |     14975 |     16302 |     17347 |       338 |

### GMSetzer invalid-utf8-v1 parse syntax-on 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      1253 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      1253 |
| Time (wall clock) (μs) *    |      3863 |      3930 |      3979 |      4006 |      4067 |      4522 |      5875 |      1253 |

### GMSetzer valid-multibyte-v1 parse syntax-off 16 KiB (bytes: 16385, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       426 |       426 |       426 |       426 |       426 |       426 |       426 |     10000 |
| Malloc (total) *            |       477 |       477 |       477 |       477 |       477 |       477 |       477 |     10000 |
| Time (wall clock) (μs) *    |       167 |       168 |       168 |       172 |       177 |       226 |      1622 |     10000 |

### GMSetzer valid-multibyte-v1 parse syntax-off 256 KiB (bytes: 262155, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6788 |      6788 |      6788 |      6788 |      6788 |      6788 |      6788 |      1577 |
| Malloc (total) *            |      7499 |      7499 |      7499 |      7499 |      7499 |      7499 |      7499 |      1577 |
| Time (wall clock) (μs) *    |      3100 |      3125 |      3135 |      3164 |      3242 |      3621 |      5176 |      1577 |

### GMSetzer valid-multibyte-v1 parse syntax-off 64 KiB (bytes: 65560, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1699 |      1699 |      1699 |      1699 |      1699 |      1699 |      1699 |      4434 |
| Malloc (total) *            |      1882 |      1882 |      1882 |      1882 |      1882 |      1882 |      1882 |      4434 |
| Time (wall clock) (μs) *    |      1087 |      1096 |      1122 |      1129 |      1157 |      1302 |      3011 |      4434 |

### GMSetzer valid-multibyte-v1 parse syntax-on 16 KiB (bytes: 16385, corpus: valid-multibyte-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       426 |       426 |       426 |       426 |       426 |       426 |       426 |     10000 |
| Malloc (total) *            |       477 |       477 |       477 |       477 |       477 |       477 |       477 |     10000 |
| Time (wall clock) (μs) *    |       167 |       168 |       168 |       171 |       175 |       222 |      1653 |     10000 |

### GMSetzer valid-multibyte-v1 parse syntax-on 256 KiB (bytes: 262155, corpus: valid-multibyte-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6788 |      6788 |      6788 |      6788 |      6788 |      6788 |      6788 |      1583 |
| Malloc (total) *            |      7499 |      7499 |      7499 |      7499 |      7499 |      7499 |      7499 |      1583 |
| Time (wall clock) (μs) *    |      3102 |      3125 |      3135 |      3154 |      3195 |      3529 |      5138 |      1583 |

### GMSetzer valid-multibyte-v1 parse syntax-on 64 KiB (bytes: 65560, corpus: valid-multibyte-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1699 |      1699 |      1699 |      1699 |      1699 |      1699 |      1699 |      4432 |
| Malloc (total) *            |      1882 |      1882 |      1882 |      1882 |      1882 |      1882 |      1882 |      4432 |
| Time (wall clock) (μs) *    |      1089 |      1098 |      1124 |      1129 |      1155 |      1283 |      2840 |      4432 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-off 16 KiB (bytes: 16385, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       676 |       676 |       676 |       676 |       676 |       676 |       676 |     10000 |
| Malloc (total) *            |      3303 |      3303 |      3303 |      3303 |      3303 |      3303 |      3303 |     10000 |
| Time (wall clock) (μs) *    |       373 |       376 |       378 |       387 |       403 |       474 |      2002 |     10000 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-off 256 KiB (bytes: 262145, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        11 |        11 |        11 |        11 |        11 |        11 |        11 |       719 |
| Malloc (total) (K) *        |        52 |        52 |        52 |        52 |        52 |        52 |        52 |       719 |
| Time (wall clock) (μs) *    |      6815 |      6881 |      6910 |      6959 |      7074 |      7967 |      8812 |       719 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-off 64 KiB (bytes: 65545, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2657 |      2657 |      2657 |      2657 |      2657 |      2657 |      2657 |      3233 |
| Malloc (total) (K) *        |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      3233 |
| Time (wall clock) (μs) *    |      1494 |      1507 |      1540 |      1554 |      1590 |      1730 |      4171 |      3233 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-on 16 KiB (bytes: 16385, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       712 |       712 |       712 |       712 |       712 |       712 |       712 |     10000 |
| Malloc (total) *            |      3304 |      3304 |      3304 |      3304 |      3304 |      3304 |      3304 |     10000 |
| Time (wall clock) (μs) *    |       416 |       420 |       422 |       432 |       449 |       515 |      4627 |     10000 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-on 256 KiB (bytes: 262145, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        11 |        11 |        11 |        11 |        11 |        11 |        11 |       649 |
| Malloc (total) (K) *        |        52 |        52 |        52 |        52 |        52 |        52 |        52 |       649 |
| Time (wall clock) (μs) *    |      7536 |      7586 |      7610 |      7660 |      7786 |     11198 |     11786 |       649 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-on 64 KiB (bytes: 65545, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2778 |      2778 |      2778 |      2778 |      2778 |      2778 |      2778 |      2873 |
| Malloc (total) (K) *        |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      2873 |
| Time (wall clock) (μs) *    |      1671 |      1699 |      1731 |      1741 |      1786 |      2054 |      3241 |      2873 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-off 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       574 |       574 |       574 |       574 |       574 |       574 |       574 |     10000 |
| Malloc (total) *            |      2757 |      2757 |      2757 |      2757 |      2757 |      2757 |      2757 |     10000 |
| Time (wall clock) (μs) *    |       315 |       318 |       321 |       327 |       337 |       402 |      2135 |     10000 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-off 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      9249 |      9249 |      9249 |      9249 |      9249 |      9249 |      9249 |       855 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       855 |
| Time (wall clock) (μs) *    |      5733 |      5784 |      5808 |      5853 |      5935 |      6463 |      7465 |       855 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-off 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2250 |      2250 |      2250 |      2250 |      2250 |      2250 |      2250 |      3812 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      3812 |
| Time (wall clock) (μs) *    |      1263 |      1278 |      1307 |      1314 |      1342 |      1479 |      3035 |      3812 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-on 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       607 |       607 |       607 |       607 |       607 |       607 |       607 |     10000 |
| Malloc (total) *            |      2758 |      2758 |      2758 |      2758 |      2758 |      2758 |      2758 |     10000 |
| Time (wall clock) (μs) *    |       361 |       365 |       368 |       376 |       392 |       462 |      1982 |     10000 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-on 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      9804 |      9804 |      9804 |      9804 |      9804 |      9804 |      9804 |       753 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       753 |
| Time (wall clock) (μs) *    |      6517 |      6570 |      6599 |      6644 |      6717 |      7700 |      8355 |       753 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-on 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2359 |      2359 |      2359 |      2359 |      2359 |      2359 |      2359 |      3341 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      3341 |
| Time (wall clock) (μs) *    |      1446 |      1460 |      1486 |      1505 |      1543 |      1693 |      3171 |      3341 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-off 16 KiB (bytes: 16385, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       221 |       221 |       221 |       221 |       221 |       221 |       221 |     10000 |
| Malloc (total) *            |       960 |       960 |       960 |       960 |       960 |       960 |       960 |     10000 |
| Time (wall clock) (μs) *    |       112 |       113 |       113 |       116 |       117 |       155 |      1675 |     10000 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-off 256 KiB (bytes: 262155, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3582 |      3582 |      3582 |      3582 |      3582 |      3582 |      3582 |      2400 |
| Malloc (total) (K) *        |        15 |        15 |        15 |        15 |        15 |        15 |        15 |      2400 |
| Time (wall clock) (μs) *    |      1863 |      1921 |      2181 |      2198 |      2226 |      2537 |      3956 |      2400 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-off 64 KiB (bytes: 65560, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       934 |       934 |       934 |       934 |       934 |       934 |       934 |     10000 |
| Malloc (total) *            |      3774 |      3774 |      3774 |      3774 |      3774 |      3774 |      3774 |     10000 |
| Time (wall clock) (μs) *    |       453 |       457 |       459 |       470 |       487 |       565 |      1932 |     10000 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-on 16 KiB (bytes: 16385, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       221 |       221 |       221 |       221 |       221 |       221 |       221 |     10000 |
| Malloc (total) *            |       960 |       960 |       960 |       960 |       960 |       960 |       960 |     10000 |
| Time (wall clock) (μs) *    |       121 |       122 |       123 |       126 |       127 |       176 |      1556 |     10000 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-on 256 KiB (bytes: 262155, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3582 |      3582 |      3582 |      3582 |      3582 |      3582 |      3582 |      2251 |
| Malloc (total) (K) *        |        15 |        15 |        15 |        15 |        15 |        15 |        15 |      2251 |
| Time (wall clock) (μs) *    |      1991 |      2067 |      2281 |      2341 |      2361 |      2570 |      3958 |      2251 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-on 64 KiB (bytes: 65560, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       934 |       934 |       934 |       934 |       934 |       934 |       934 |      9890 |
| Malloc (total) *            |      3774 |      3774 |      3774 |      3774 |      3774 |      3774 |      3774 |      9890 |
| Time (wall clock) (μs) *    |       487 |       492 |       495 |       507 |       525 |       601 |      2012 |      9890 |

