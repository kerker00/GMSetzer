
## Baseline 'Current_run'

```
Host 'BlackBook.local' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer footnotes-repeated-v1 parse syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        59 |        59 |        59 |        59 |        59 |        59 |        59 |        89 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        89 |
| Time (wall clock) (μs) *    |     50717 |     53314 |     54788 |     57901 |     61637 |    134969 |    134969 |        89 |

### GMSetzer footnotes-repeated-v1 parse syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        72 |        72 |        72 |        72 |        72 |        72 |        72 |        80 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        80 |
| Time (wall clock) (μs) *    |     56035 |     59507 |     61145 |     63701 |     69599 |     84928 |     84928 |        80 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        92 |        92 |        92 |        92 |        92 |        92 |        92 |        61 |
| Malloc (total) (K) *        |       271 |       271 |       271 |       271 |       271 |       271 |       271 |        61 |
| Time (wall clock) (μs) *    |     74610 |     78774 |     80085 |     84214 |     89981 |    141735 |    141735 |        61 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       105 |       105 |       105 |       105 |       105 |       105 |       105 |        63 |
| Malloc (total) (K) *        |       271 |       271 |       271 |       271 |       271 |       271 |       271 |        63 |
| Time (wall clock) (μs) *    |     79405 |     80019 |     80216 |     80740 |     81461 |     85344 |     85344 |        63 |

### GMSetzer m5-composed-v1 parse syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        65 |        65 |        65 |        65 |        65 |        65 |        65 |        93 |
| Malloc (total) (K) *        |       260 |       260 |       260 |       260 |       260 |       260 |       260 |        93 |
| Time (wall clock) (μs) *    |     53188 |     53543 |     53740 |     54002 |     54559 |     56005 |     56005 |        93 |

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       101 |       101 |       101 |       101 |       101 |       101 |       101 |        54 |
| Malloc (total) (K) *        |       262 |       262 |       262 |       262 |       262 |       262 |       262 |        54 |
| Time (wall clock) (μs) *    |     91712 |     92078 |     92471 |     92930 |     94044 |     94862 |     94862 |        54 |

### GMSetzer m5-composed-v1 parse-render syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        78 |        78 |        78 |        78 |        78 |        78 |        78 |        67 |
| Malloc (total) (K) *        |       376 |       376 |       376 |       376 |       376 |       376 |       376 |        67 |
| Time (wall clock) (μs) *    |     74309 |     74842 |     75170 |     75563 |     76218 |     79026 |     79026 |        67 |

### GMSetzer m5-composed-v1 parse-render syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       114 |       114 |       114 |       114 |       114 |       114 |       114 |        45 |
| Malloc (total) (K) *        |       378 |       378 |       378 |       378 |       378 |       378 |       378 |        45 |
| Time (wall clock) (μs) *    |    110707 |    111215 |    111608 |    112460 |    114426 |    124114 |    124114 |        45 |

