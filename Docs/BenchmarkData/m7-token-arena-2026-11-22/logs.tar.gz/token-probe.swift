import Foundation
import GMSetzer

struct Example: Decodable { let example: Int; let markdown: String }
struct TokenRecord: Codable { let role: String; let lower: Int; let upper: Int; let owner: Int }
struct Record: Codable { let profile: String; let example: Int; let tokens: [TokenRecord] }
var records: [Record] = []
for (name, profile, path) in [("commonmark", Profile.commonMark, CommandLine.arguments[1]), ("gfm", Profile.gfm, CommandLine.arguments[2])] {
    let examples = try JSONDecoder().decode([Example].self, from: Data(contentsOf: URL(fileURLWithPath: path)))
    for example in examples {
        let document = MarkdownParser(profile: profile, collectSyntaxDetails: true).parse(example.markdown)
        records.append(Record(profile: name, example: example.example, tokens: document.tokens!.map {
            TokenRecord(role: $0.role, lower: $0.range.lowerBound, upper: $0.range.upperBound, owner: $0.owner)
        }))
    }
}
let encoder = JSONEncoder()
encoder.outputFormatting = [.sortedKeys]
FileHandle.standardOutput.write(try encoder.encode(records))
