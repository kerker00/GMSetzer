
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer long-emphasis-v1 parse syntax-off 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2380 |      2380 |      2380 |      2380 |      2380 |      2380 |      2380 |     10000 |
| Malloc (total) *            |        45 |        45 |        45 |        45 |        45 |        45 |        45 |     10000 |
| Time (wall clock) (μs) *    |       253 |       265 |       266 |       271 |       285 |       325 |       467 |     10000 |

### GMSetzer long-emphasis-v1 parse syntax-off 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        38 |        38 |        38 |        38 |        38 |        38 |        38 |      1143 |
| Malloc (total) *            |        56 |        56 |        56 |        56 |        56 |        56 |        56 |      1143 |
| Time (wall clock) (μs) *    |      4189 |      4329 |      4366 |      4415 |      4465 |      4579 |      5355 |      1143 |

### GMSetzer long-emphasis-v1 parse syntax-off 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      4588 |
| Malloc (total) *            |        51 |        51 |        51 |        51 |        51 |        51 |        51 |      4588 |
| Time (wall clock) (μs) *    |      1054 |      1069 |      1077 |      1095 |      1134 |      1225 |      1759 |      4588 |

### GMSetzer long-emphasis-v1 parse syntax-on 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3951 |      3951 |      3951 |      3951 |      3951 |      3951 |      3951 |     10000 |
| Malloc (total) *            |        74 |        74 |        74 |        74 |        74 |        74 |        74 |     10000 |
| Time (wall clock) (μs) *    |       416 |       427 |       432 |       446 |       465 |       505 |       732 |     10000 |

### GMSetzer long-emphasis-v1 parse syntax-on 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        76 |        76 |        76 |        76 |        76 |        76 |        76 |       684 |
| Malloc (total) *            |        94 |        94 |        94 |        94 |        94 |        94 |        94 |       684 |
| Time (wall clock) (μs) *    |      7081 |      7213 |      7279 |      7401 |      7496 |      7782 |      8434 |       684 |

### GMSetzer long-emphasis-v1 parse syntax-on 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        18 |        18 |        18 |        18 |        18 |        18 |        18 |      2672 |
| Malloc (total) *            |        84 |        84 |        84 |        84 |        84 |        84 |        84 |      2672 |
| Time (wall clock) (μs) *    |      1686 |      1716 |      1746 |      1830 |      1965 |      3574 |     43163 |      2672 |

### GMSetzer m5-composed-v1 parse syntax-on 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6396 |      6396 |      6396 |      6396 |      6396 |      6396 |      6396 |       796 |
| Malloc (total) (K) *        |        17 |        17 |        17 |        17 |        17 |        17 |        17 |       796 |
| Time (wall clock) (μs) *    |      5881 |      5980 |      6087 |      6271 |      6607 |      9593 |     38824 |       796 |

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       101 |       101 |       101 |       101 |       101 |       101 |       101 |        51 |
| Malloc (total) (K) *        |       262 |       262 |       262 |       262 |       262 |       262 |       262 |        51 |
| Time (wall clock) (μs) *    |     91209 |     93061 |     96207 |    101712 |    105775 |    122016 |    122016 |        51 |

### GMSetzer m5-composed-v1 parse syntax-on 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        25 |        25 |        25 |        25 |        25 |        25 |        25 |       214 |
| Malloc (total) (K) *        |        66 |        66 |        66 |        66 |        66 |        66 |        66 |       214 |
| Time (wall clock) (μs) *    |     22523 |     22856 |     23151 |     23462 |     23790 |     24379 |     61660 |       214 |

### GMSetzer open-brackets-v1 parse syntax-off 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      5270 |
| Malloc (total) *            |        63 |        63 |        63 |        63 |        63 |        63 |        63 |      5270 |
| Time (wall clock) (μs) *    |       910 |       926 |       937 |       961 |       990 |      1062 |      1410 |      5270 |

### GMSetzer open-brackets-v1 parse syntax-off 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       174 |       174 |       174 |       174 |       174 |       174 |       174 |       279 |
| Malloc (total) *            |        76 |        76 |        76 |        76 |        76 |        76 |        76 |       279 |
| Time (wall clock) (μs) *    |     15534 |     16654 |     17318 |     18579 |     20136 |     28770 |     30732 |       279 |

### GMSetzer open-brackets-v1 parse syntax-off 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        44 |        44 |        44 |        44 |        44 |        44 |        44 |      1290 |
| Malloc (total) *            |        70 |        70 |        70 |        70 |        70 |        70 |        70 |      1290 |
| Time (wall clock) (μs) *    |      3732 |      3797 |      3846 |      3910 |      4016 |      4338 |      5103 |      1290 |

