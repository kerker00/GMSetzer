
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer long-emphasis-v1 parse syntax-on 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        80 |        80 |        80 |        80 |        80 |        80 |        80 |         2 |
| Malloc (total) (K) *        |       262 |       262 |       262 |       262 |       262 |       262 |       262 |         2 |

### Allocations: HardeningBenchmarks:GMSetzer long-emphasis-v1 parse syntax-on 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

2 iterations, 524,438 allocations (262,219.0/iteration), 160.9 MB, 24 unique stacks

**#1  262,152 allocations (131,076.0/iteration), 50.0%, 57.3 MB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  InlineParser.emphasis(bottom:) in HardeningBenchmarks
    2  InlineParser.parse() in HardeningBenchmarks
    3  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#2  262,148 allocations (131,074.0/iteration), 50.0%, 12.6 MB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#3  52 allocations (26.0/iteration), 0.0%, 56.6 MB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.append(_:range:segments:fallbackLiteral:to:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#4  36 allocations (18.0/iteration), 0.0%, 32.0 MB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.record(_:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#5  4 allocations (2.0/iteration), 0.0%, 524.5 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized InlineInput.init(_:children:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#6  4 allocations (2.0/iteration), 0.0%, 2.7 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.reserveCapacity(_:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#7  4 allocations (2.0/iteration), 0.0%, 1.3 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.append(_:range:segments:fallbackLiteral:to:) in HardeningBenchmarks
    2  BlockParser.appendText(_:to:) in HardeningBenchmarks
    3  BlockParser.finishLeaf(headingLevel:closingLine:tablePreamble:) in HardeningBenchmarks
    4  BlockParser.parse() in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#8  4 allocations (2.0/iteration), 0.0%, 704 B**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.reserveCapacity(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#9  4 allocations (2.0/iteration), 0.0%, 512 B**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  InlineParser.delimiterRun() in HardeningBenchmarks
    2  InlineParser.parse() in HardeningBenchmarks
    3  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#10  2 allocations (1.0/iteration), 0.0%, 1.2 MB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  InlineParser.reset(to:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#11  2 allocations (1.0/iteration), 0.0%, 524.4 KB**
```
    0  closure #1 in BlockParser.decode(_:) in HardeningBenchmarks
    1  BlockParser.appendText(_:to:) in HardeningBenchmarks
    2  BlockParser.finishLeaf(headingLevel:closingLine:tablePreamble:) in HardeningBenchmarks
    3  BlockParser.parse() in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#12  2 allocations (1.0/iteration), 0.0%, 131.1 KB**
```
    0  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    1  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#13  2 allocations (1.0/iteration), 0.0%, 2.1 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    4  BlockParser.parse() in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#14  2 allocations (1.0/iteration), 0.0%, 2.1 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    4  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#15  2 allocations (1.0/iteration), 0.0%, 384 B**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized static BlockParser.scanLines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#16  2 allocations (1.0/iteration), 0.0%, 352 B**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized Array.reserveCapacity(_:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#17  2 allocations (1.0/iteration), 0.0%, 320 B**
```
    0  DocumentBuilder.init(source:collectSyntaxDetails:) in HardeningBenchmarks
    1  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    2  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    3  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#18  2 allocations (1.0/iteration), 0.0%, 320 B**
```
    0  DocumentBuilder.init(source:collectSyntaxDetails:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#19  2 allocations (1.0/iteration), 0.0%, 304 B**
```
    0  InlineParser.emphasis(bottom:) in HardeningBenchmarks
    1  InlineParser.parse() in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#20  2 allocations (1.0/iteration), 0.0%, 112 B**
```
    0  specialized Array.init(repeating:count:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#21  2 allocations (1.0/iteration), 0.0%, 96 B**
```
    0  specialized _ContiguousArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized ContiguousArray._createNewBuffer(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#22  2 allocations (1.0/iteration), 0.0%, 80 B**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  Document.children(of:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#23  2 allocations (1.0/iteration), 0.0%, 80 B**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  Document.children(of:into:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#24  2 allocations (1.0/iteration), 0.0%, 70 B**
```
    0  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    1  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  BlockParser.parse() in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

Writing to /private/tmp/gmsetzer-m7-tokens-oeidfkfq/profile-before/HardeningBenchmarks.GMSetzer_long-emphasis-v1_parse_syntax-on_256_KiB_(bytes:_262150,_corpus:_long-emphasis-v1,_profile:_commonmark,_syntax:_on).allocations.json
