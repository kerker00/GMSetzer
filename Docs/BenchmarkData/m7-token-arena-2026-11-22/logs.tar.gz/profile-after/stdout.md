
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer long-emphasis-v1 parse syntax-on 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        76 |        76 |        76 |        76 |        76 |        76 |        76 |       563 |
| Malloc (total) *            |        94 |        94 |        94 |        94 |        94 |        94 |        94 |       563 |

### Allocations: HardeningBenchmarks:GMSetzer long-emphasis-v1 parse syntax-on 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

563 iterations, 52,922 allocations (94.0/iteration), 42.7 GB, 23 unique stacks

**#1  14,638 allocations (26.0/iteration), 27.7%, 15.9 GB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.append(_:range:segments:fallbackLiteral:to:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#2  12,386 allocations (22.0/iteration), 23.4%, 18.6 GB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  InlineParser.emphasis(bottom:) in HardeningBenchmarks
    2  InlineParser.parse() in HardeningBenchmarks
    3  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#3  10,134 allocations (18.0/iteration), 19.1%, 7.5 GB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.record(_:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#4  2,252 allocations (4.0/iteration), 4.3%, 184.7 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#5  1,126 allocations (2.0/iteration), 2.1%, 147.6 MB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized InlineInput.init(_:children:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#6  1,126 allocations (2.0/iteration), 2.1%, 765.7 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.reserveCapacity(_:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#7  1,126 allocations (2.0/iteration), 2.1%, 360.3 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.append(_:range:segments:fallbackLiteral:to:) in HardeningBenchmarks
    2  BlockParser.appendText(_:to:) in HardeningBenchmarks
    3  BlockParser.finishLeaf(headingLevel:closingLine:tablePreamble:) in HardeningBenchmarks
    4  BlockParser.parse() in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#8  1,126 allocations (2.0/iteration), 2.1%, 198.2 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.reserveCapacity(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#9  1,126 allocations (2.0/iteration), 2.1%, 144.1 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  InlineParser.delimiterRun() in HardeningBenchmarks
    2  InlineParser.parse() in HardeningBenchmarks
    3  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#10  563 allocations (1.0/iteration), 1.1%, 332.1 MB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  InlineParser.reset(to:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#11  563 allocations (1.0/iteration), 1.1%, 147.6 MB**
```
    0  closure #1 in BlockParser.decode(_:) in HardeningBenchmarks
    1  BlockParser.appendText(_:to:) in HardeningBenchmarks
    2  BlockParser.finishLeaf(headingLevel:closingLine:tablePreamble:) in HardeningBenchmarks
    3  BlockParser.parse() in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#12  563 allocations (1.0/iteration), 1.1%, 36.9 MB**
```
    0  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    1  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#13  563 allocations (1.0/iteration), 1.1%, 594.5 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    4  BlockParser.parse() in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#14  563 allocations (1.0/iteration), 1.1%, 594.5 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    4  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#15  563 allocations (1.0/iteration), 1.1%, 108.1 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized static BlockParser.scanLines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#16  563 allocations (1.0/iteration), 1.1%, 90.1 KB**
```
    0  DocumentBuilder.init(source:collectSyntaxDetails:) in HardeningBenchmarks
    1  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    2  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    3  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#17  563 allocations (1.0/iteration), 1.1%, 90.1 KB**
```
    0  DocumentBuilder.init(source:collectSyntaxDetails:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#18  563 allocations (1.0/iteration), 1.1%, 85.6 KB**
```
    0  InlineParser.emphasis(bottom:) in HardeningBenchmarks
    1  InlineParser.parse() in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#19  563 allocations (1.0/iteration), 1.1%, 31.5 KB**
```
    0  specialized Array.init(repeating:count:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#20  563 allocations (1.0/iteration), 1.1%, 27.0 KB**
```
    0  specialized _ContiguousArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized ContiguousArray._createNewBuffer(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#21  563 allocations (1.0/iteration), 1.1%, 22.5 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  Document.children(of:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#22  563 allocations (1.0/iteration), 1.1%, 22.5 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  Document.children(of:into:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#23  563 allocations (1.0/iteration), 1.1%, 19.7 KB**
```
    0  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    1  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  BlockParser.parse() in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

Writing to /private/tmp/gmsetzer-m7-tokens-oeidfkfq/profile-after/HardeningBenchmarks.GMSetzer_long-emphasis-v1_parse_syntax-on_256_KiB_(bytes:_262150,_corpus:_long-emphasis-v1,_profile:_commonmark,_syntax:_on).allocations.json
