
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer long-emphasis-v1 parse syntax-off 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2380 |      2380 |      2380 |      2380 |      2380 |      2380 |      2380 |     10000 |
| Malloc (total) *            |        45 |        45 |        45 |        45 |        45 |        45 |        45 |     10000 |
| Time (wall clock) (μs) *    |       278 |       284 |       290 |       292 |       299 |       343 |       492 |     10000 |

### GMSetzer long-emphasis-v1 parse syntax-off 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        38 |        38 |        38 |        38 |        38 |        38 |        38 |      1045 |
| Malloc (total) *            |        56 |        56 |        56 |        56 |        56 |        56 |        56 |      1045 |
| Time (wall clock) (μs) *    |      4566 |      4723 |      4772 |      4825 |      4899 |      5157 |      6074 |      1045 |

### GMSetzer long-emphasis-v1 parse syntax-off 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      4242 |
| Malloc (total) *            |        51 |        51 |        51 |        51 |        51 |        51 |        51 |      4242 |
| Time (wall clock) (μs) *    |      1133 |      1166 |      1172 |      1180 |      1200 |      1292 |      1383 |      4242 |

### GMSetzer long-emphasis-v1 parse syntax-on 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      4214 |      4214 |      4214 |      4214 |      4214 |      4214 |      4214 |      2658 |
| Malloc (total) (K) *        |        16 |        16 |        16 |        16 |        16 |        16 |        16 |      2658 |
| Time (wall clock) (μs) *    |      1793 |      1855 |      1878 |      1895 |      1925 |      2020 |      2384 |      2658 |

### GMSetzer long-emphasis-v1 parse syntax-on 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        80 |        80 |        80 |        80 |        80 |        80 |        80 |       169 |
| Malloc (total) (K) *        |       262 |       262 |       262 |       262 |       262 |       262 |       262 |       169 |
| Time (wall clock) (μs) *    |     29108 |     29590 |     29721 |     29884 |     30048 |     30507 |     30636 |       169 |

### GMSetzer long-emphasis-v1 parse syntax-on 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        19 |        19 |        19 |        19 |        19 |        19 |        19 |       679 |
| Malloc (total) (K) *        |        66 |        66 |        66 |        66 |        66 |        66 |        66 |       679 |
| Time (wall clock) (μs) *    |      7170 |      7320 |      7361 |      7414 |      7475 |      7655 |      7972 |       679 |

### GMSetzer m5-composed-v1 parse syntax-on 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6566 |      6566 |      6566 |      6566 |      6566 |      6566 |      6566 |       817 |
| Malloc (total) (K) *        |        19 |        19 |        19 |        19 |        19 |        19 |        19 |       817 |
| Time (wall clock) (μs) *    |      6042 |      6083 |      6115 |      6160 |      6205 |      6304 |      6740 |       817 |

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       103 |       103 |       103 |       103 |       103 |       103 |       103 |        53 |
| Malloc (total) (K) *        |       296 |       296 |       296 |       296 |       296 |       296 |       296 |        53 |
| Time (wall clock) (μs) *    |     94114 |     94700 |     94831 |     95355 |     95683 |     97034 |     97034 |        53 |

### GMSetzer m5-composed-v1 parse syntax-on 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        26 |        26 |        26 |        26 |        26 |        26 |        26 |       212 |
| Malloc (total) (K) *        |        75 |        75 |        75 |        75 |        75 |        75 |        75 |       212 |
| Time (wall clock) (μs) *    |     23359 |     23544 |     23642 |     23740 |     23871 |     25149 |     25528 |       212 |

### GMSetzer open-brackets-v1 parse syntax-off 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      4621 |
| Malloc (total) *            |        63 |        63 |        63 |        63 |        63 |        63 |        63 |      4621 |
| Time (wall clock) (μs) *    |      1044 |      1061 |      1068 |      1082 |      1109 |      1200 |     14836 |      4621 |

### GMSetzer open-brackets-v1 parse syntax-off 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       174 |       174 |       174 |       174 |       174 |       174 |       174 |       277 |
| Malloc (total) *            |        76 |        76 |        76 |        76 |        76 |        76 |        76 |       277 |
| Time (wall clock) (μs) *    |     17480 |     17711 |     17809 |     18022 |     18399 |     19857 |     56552 |       277 |

### GMSetzer open-brackets-v1 parse syntax-off 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        44 |        44 |        44 |        44 |        44 |        44 |        44 |      1131 |
| Malloc (total) *            |        70 |        70 |        70 |        70 |        70 |        70 |        70 |      1131 |
| Time (wall clock) (μs) *    |      4289 |      4354 |      4395 |      4465 |      4534 |      4805 |      5127 |      1131 |

