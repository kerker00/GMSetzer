
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### cmark-gfm (C) open-brackets-v1 parse 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3672 |      3672 |      3672 |      3672 |      3672 |      3672 |      3672 |      3645 |
| Malloc (total) (K) *        |        33 |        33 |        33 |        33 |        33 |        33 |        33 |      3645 |
| Time (wall clock) (μs) *    |      1297 |      1308 |      1312 |      1329 |      1386 |      1655 |     62383 |      3645 |

