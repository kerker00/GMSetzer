
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer m5-composed-v1 parse syntax-off 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      4223 |      4223 |      4223 |      4223 |      4223 |      4223 |      4223 |      1464 |
| Malloc (total) (K) *        |        17 |        17 |        17 |        17 |        17 |        17 |        17 |      1464 |
| Time (wall clock) (μs) *    |      3308 |      3396 |      3400 |      3406 |      3432 |      3639 |      9542 |      1464 |

