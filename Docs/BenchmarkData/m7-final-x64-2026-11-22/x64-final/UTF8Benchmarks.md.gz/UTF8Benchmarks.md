
## Baseline 'Current_run'

```
Host 'PowerG5' with 4 'x86_64' processors with 31 GB memory, running:
#1 SMP PREEMPT_DYNAMIC Fri, 13 Nov 2026 19:45:18 +0000
```
## UTF8Benchmarks

### GMSetzer invalid-compatible-v1 parse syntax-off 16 KiB (bytes: 16385, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1538 |      1538 |      1538 |      1538 |      1538 |      1538 |      1538 |      4139 |
| Malloc (total) *            |      3285 |      3285 |      3285 |      3285 |      3285 |      3285 |      3285 |      4139 |
| Time (wall clock) (μs) *    |      1169 |      1181 |      1206 |      1211 |      1217 |      1366 |      4149 |      4139 |

### GMSetzer invalid-compatible-v1 parse syntax-off 256 KiB (bytes: 262145, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        25 |        25 |        25 |        25 |        25 |        25 |        25 |       342 |
| Malloc (total) (K) *        |        52 |        52 |        52 |        52 |        52 |        52 |        52 |       342 |
| Time (wall clock) (μs) *    |     14448 |     14508 |     14574 |     14606 |     14705 |     17334 |     17373 |       342 |

### GMSetzer invalid-compatible-v1 parse syntax-off 64 KiB (bytes: 65545, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6150 |      6150 |      6150 |      6150 |      6150 |      6150 |      6150 |      1360 |
| Malloc (total) (K) *        |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      1360 |
| Time (wall clock) (μs) *    |      3531 |      3564 |      3578 |      3656 |      3686 |      7447 |     14805 |      1360 |

### GMSetzer invalid-compatible-v1 parse syntax-on 16 KiB (bytes: 16385, corpus: invalid-compatible-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1538 |      1538 |      1538 |      1538 |      1538 |      1538 |      1538 |      4185 |
| Malloc (total) *            |      3285 |      3285 |      3285 |      3285 |      3285 |      3285 |      3285 |      4185 |
| Time (wall clock) (μs) *    |      1169 |      1179 |      1181 |      1184 |      1212 |      1368 |      3998 |      4185 |

### GMSetzer invalid-compatible-v1 parse syntax-on 256 KiB (bytes: 262145, corpus: invalid-compatible-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        25 |        25 |        25 |        25 |        25 |        25 |        25 |       342 |
| Malloc (total) (K) *        |        52 |        52 |        52 |        52 |        52 |        52 |        52 |       342 |
| Time (wall clock) (μs) *    |     14452 |     14508 |     14574 |     14606 |     14713 |     17285 |     18389 |       342 |

### GMSetzer invalid-compatible-v1 parse syntax-on 64 KiB (bytes: 65545, corpus: invalid-compatible-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6150 |      6150 |      6150 |      6150 |      6150 |      6150 |      6150 |      1379 |
| Malloc (total) (K) *        |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      1379 |
| Time (wall clock) (μs) *    |      3532 |      3568 |      3586 |      3660 |      3684 |      4223 |      5400 |      1379 |

### GMSetzer invalid-utf8-v1 parse syntax-off 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      4351 |
| Malloc (total) *            |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      4351 |
| Time (wall clock) (μs) *    |      1128 |      1134 |      1135 |      1138 |      1168 |      1335 |      3236 |      4351 |

### GMSetzer invalid-utf8-v1 parse syntax-off 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       342 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       342 |
| Time (wall clock) (μs) *    |     14495 |     14533 |     14549 |     14582 |     14737 |     16212 |     17322 |       342 |

### GMSetzer invalid-utf8-v1 parse syntax-off 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      1286 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      1286 |
| Time (wall clock) (μs) *    |      3823 |      3836 |      3842 |      3875 |      3944 |      4542 |      6986 |      1286 |

### GMSetzer invalid-utf8-v1 parse syntax-on 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      4342 |
| Malloc (total) *            |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      4342 |
| Time (wall clock) (μs) *    |      1128 |      1134 |      1136 |      1139 |      1174 |      1347 |      3994 |      4342 |

### GMSetzer invalid-utf8-v1 parse syntax-on 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       341 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       341 |
| Time (wall clock) (μs) *    |     14494 |     14557 |     14590 |     14615 |     14901 |     16876 |     18777 |       341 |

### GMSetzer invalid-utf8-v1 parse syntax-on 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      1266 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      1266 |
| Time (wall clock) (μs) *    |      3828 |      3848 |      3934 |      3963 |      4043 |      4547 |      6799 |      1266 |

### GMSetzer valid-multibyte-v1 parse syntax-off 16 KiB (bytes: 16385, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       426 |       426 |       426 |       426 |       426 |       426 |       426 |     10000 |
| Malloc (total) *            |       477 |       477 |       477 |       477 |       477 |       477 |       477 |     10000 |
| Time (wall clock) (μs) *    |       165 |       167 |       167 |       171 |       172 |       208 |      2966 |     10000 |

### GMSetzer valid-multibyte-v1 parse syntax-off 256 KiB (bytes: 262155, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6788 |      6788 |      6788 |      6788 |      6788 |      6788 |      6788 |      1570 |
| Malloc (total) *            |      7499 |      7499 |      7499 |      7499 |      7499 |      7499 |      7499 |      1570 |
| Time (wall clock) (μs) *    |      3027 |      3121 |      3181 |      3191 |      3201 |      3695 |      6157 |      1570 |

### GMSetzer valid-multibyte-v1 parse syntax-off 64 KiB (bytes: 65560, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1699 |      1699 |      1699 |      1699 |      1699 |      1699 |      1699 |      4500 |
| Malloc (total) *            |      1882 |      1882 |      1882 |      1882 |      1882 |      1882 |      1882 |      4500 |
| Time (wall clock) (μs) *    |      1081 |      1090 |      1104 |      1109 |      1135 |      1268 |      4030 |      4500 |

### GMSetzer valid-multibyte-v1 parse syntax-on 16 KiB (bytes: 16385, corpus: valid-multibyte-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       426 |       426 |       426 |       426 |       426 |       426 |       426 |     10000 |
| Malloc (total) *            |       477 |       477 |       477 |       477 |       477 |       477 |       477 |     10000 |
| Time (wall clock) (μs) *    |       165 |       166 |       167 |       171 |       172 |       211 |      1893 |     10000 |

### GMSetzer valid-multibyte-v1 parse syntax-on 256 KiB (bytes: 262155, corpus: valid-multibyte-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6788 |      6788 |      6788 |      6788 |      6788 |      6788 |      6788 |      1579 |
| Malloc (total) *            |      7499 |      7499 |      7499 |      7499 |      7499 |      7499 |      7499 |      1579 |
| Time (wall clock) (μs) *    |      3009 |      3105 |      3166 |      3183 |      3197 |      3738 |      5572 |      1579 |

### GMSetzer valid-multibyte-v1 parse syntax-on 64 KiB (bytes: 65560, corpus: valid-multibyte-v1, profile: commonmark, syntax: on, validation: swift-repair)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1699 |      1699 |      1699 |      1699 |      1699 |      1699 |      1699 |      4491 |
| Malloc (total) *            |      1882 |      1882 |      1882 |      1882 |      1882 |      1882 |      1882 |      4491 |
| Time (wall clock) (μs) *    |      1080 |      1091 |      1106 |      1109 |      1134 |      1258 |      3925 |      4491 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-off 16 KiB (bytes: 16385, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       676 |       676 |       676 |       676 |       676 |       676 |       676 |     10000 |
| Malloc (total) *            |      3303 |      3303 |      3303 |      3303 |      3303 |      3303 |      3303 |     10000 |
| Time (wall clock) (μs) *    |       374 |       378 |       380 |       382 |       385 |       449 |      3267 |     10000 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-off 256 KiB (bytes: 262145, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        11 |        11 |        11 |        11 |        11 |        11 |        11 |       720 |
| Malloc (total) (K) *        |        52 |        52 |        52 |        52 |        52 |        52 |        52 |       720 |
| Time (wall clock) (μs) *    |      6822 |      6877 |      6894 |      6918 |      6963 |      7696 |      9675 |       720 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-off 64 KiB (bytes: 65545, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2657 |      2657 |      2657 |      2657 |      2657 |      2657 |      2657 |      3260 |
| Malloc (total) (K) *        |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      3260 |
| Time (wall clock) (μs) *    |      1490 |      1509 |      1517 |      1526 |      1558 |      1833 |      4434 |      3260 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-on 16 KiB (bytes: 16385, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       712 |       712 |       712 |       712 |       712 |       712 |       712 |     10000 |
| Malloc (total) *            |      3304 |      3304 |      3304 |      3304 |      3304 |      3304 |      3304 |     10000 |
| Time (wall clock) (μs) *    |       422 |       429 |       430 |       432 |       440 |       499 |      3318 |     10000 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-on 256 KiB (bytes: 262145, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        11 |        11 |        11 |        11 |        11 |        11 |        11 |       648 |
| Malloc (total) (K) *        |        52 |        52 |        52 |        52 |        52 |        52 |        52 |       648 |
| Time (wall clock) (μs) *    |      7580 |      7627 |      7668 |      7692 |      7741 |      8692 |     11225 |       648 |

### cmark-gfm (C) invalid-compatible-v1 parse validation-on 64 KiB (bytes: 65545, corpus: invalid-compatible-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2778 |      2778 |      2778 |      2778 |      2778 |      2778 |      2778 |      2876 |
| Malloc (total) (K) *        |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      2876 |
| Time (wall clock) (μs) *    |      1695 |      1713 |      1718 |      1726 |      1763 |      2099 |      4646 |      2876 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-off 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       574 |       574 |       574 |       574 |       574 |       574 |       574 |     10000 |
| Malloc (total) *            |      2757 |      2757 |      2757 |      2757 |      2757 |      2757 |      2757 |     10000 |
| Time (wall clock) (μs) *    |       315 |       319 |       320 |       322 |       325 |       377 |      1872 |     10000 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-off 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      9249 |      9249 |      9249 |      9249 |      9249 |      9249 |      9249 |       862 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       862 |
| Time (wall clock) (μs) *    |      5709 |      5747 |      5763 |      5784 |      5837 |      6640 |      7328 |       862 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-off 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2250 |      2250 |      2250 |      2250 |      2250 |      2250 |      2250 |      3865 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      3865 |
| Time (wall clock) (μs) *    |      1260 |      1274 |      1279 |      1286 |      1316 |      1534 |      4711 |      3865 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-on 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       607 |       607 |       607 |       607 |       607 |       607 |       607 |     10000 |
| Malloc (total) *            |      2758 |      2758 |      2758 |      2758 |      2758 |      2758 |      2758 |     10000 |
| Time (wall clock) (μs) *    |       368 |       373 |       375 |       376 |       379 |       444 |      3122 |     10000 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-on 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      9804 |      9804 |      9804 |      9804 |      9804 |      9804 |      9804 |       746 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       746 |
| Time (wall clock) (μs) *    |      6606 |      6636 |      6652 |      6668 |      6717 |      7614 |      9438 |       746 |

### cmark-gfm (C) invalid-utf8-v1 parse validation-on 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2359 |      2359 |      2359 |      2359 |      2359 |      2359 |      2359 |      3305 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      3305 |
| Time (wall clock) (μs) *    |      1474 |      1489 |      1495 |      1502 |      1534 |      1756 |      5913 |      3305 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-off 16 KiB (bytes: 16385, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       221 |       221 |       221 |       221 |       221 |       221 |       221 |     10000 |
| Malloc (total) *            |       960 |       960 |       960 |       960 |       960 |       960 |       960 |     10000 |
| Time (wall clock) (μs) *    |       111 |       112 |       113 |       113 |       115 |       151 |      2868 |     10000 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-off 256 KiB (bytes: 262155, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3582 |      3582 |      3582 |      3582 |      3582 |      3582 |      3582 |      2490 |
| Malloc (total) (K) *        |        15 |        15 |        15 |        15 |        15 |        15 |        15 |      2490 |
| Time (wall clock) (μs) *    |      1828 |      1853 |      2091 |      2111 |      2161 |      2390 |      4917 |      2490 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-off 64 KiB (bytes: 65560, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       934 |       934 |       934 |       934 |       934 |       934 |       934 |     10000 |
| Malloc (total) *            |      3774 |      3774 |      3774 |      3774 |      3774 |      3774 |      3774 |     10000 |
| Time (wall clock) (μs) *    |       448 |       452 |       454 |       456 |       463 |       540 |      3354 |     10000 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-on 16 KiB (bytes: 16385, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       221 |       221 |       221 |       221 |       221 |       221 |       221 |     10000 |
| Malloc (total) *            |       960 |       960 |       960 |       960 |       960 |       960 |       960 |     10000 |
| Time (wall clock) (μs) *    |       122 |       124 |       124 |       124 |       127 |       157 |      2908 |     10000 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-on 256 KiB (bytes: 262155, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3582 |      3582 |      3582 |      3582 |      3582 |      3582 |      3582 |      2263 |
| Malloc (total) (K) *        |        15 |        15 |        15 |        15 |        15 |        15 |        15 |      2263 |
| Time (wall clock) (μs) *    |      2013 |      2051 |      2279 |      2310 |      2361 |      2628 |      5071 |      2263 |

### cmark-gfm (C) valid-multibyte-v1 parse validation-on 64 KiB (bytes: 65560, corpus: valid-multibyte-v1, profile: commonmark, syntax: off, validation: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       934 |       934 |       934 |       934 |       934 |       934 |       934 |      9855 |
| Malloc (total) *            |      3774 |      3774 |      3774 |      3774 |      3774 |      3774 |      3774 |      9855 |
| Time (wall clock) (μs) *    |       494 |       499 |       500 |       503 |       515 |       589 |      2017 |      9855 |

