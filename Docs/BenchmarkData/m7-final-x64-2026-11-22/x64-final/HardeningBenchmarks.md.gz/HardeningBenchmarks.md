
## Baseline 'Current_run'

```
Host 'PowerG5' with 4 'x86_64' processors with 31 GB memory, running:
#1 SMP PREEMPT_DYNAMIC Fri, 13 Nov 2026 19:45:18 +0000
```
## HardeningBenchmarks

### GMSetzer footnotes-repeated-v1 parse syntax-off 16 KiB (bytes: 16398, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3197 |      3198 |      3198 |      3198 |      3198 |      3198 |      3198 |      1042 |
| Malloc (total) (K) *        |        12 |        12 |        12 |        12 |        12 |        12 |        12 |      1042 |
| Time (wall clock) (μs) *    |      4489 |      4723 |      4755 |      4841 |      4882 |      5407 |      6497 |      1042 |

### GMSetzer footnotes-repeated-v1 parse syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        58 |        58 |        58 |        58 |        58 |        58 |        58 |        68 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        68 |
| Time (wall clock) (μs) *    |     73327 |     73990 |     74449 |     75235 |     76022 |     76578 |     76578 |        68 |

### GMSetzer footnotes-repeated-v1 parse syntax-off 64 KiB (bytes: 65538, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        14 |        14 |        14 |        14 |        14 |        14 |        14 |       286 |
| Malloc (total) (K) *        |        46 |        46 |        46 |        46 |        46 |        46 |        46 |       286 |
| Time (wall clock) (μs) *    |     17202 |     17383 |     17416 |     17482 |     17891 |     19071 |     20193 |       286 |

### GMSetzer footnotes-repeated-v1 parse syntax-on 16 KiB (bytes: 16398, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3854 |      3854 |      3854 |      3854 |      3854 |      3855 |      3855 |       931 |
| Malloc (total) (K) *        |        12 |        12 |        12 |        12 |        12 |        12 |        12 |       931 |
| Time (wall clock) (μs) *    |      5246 |      5284 |      5308 |      5353 |      5538 |      6095 |      8249 |       931 |

### GMSetzer footnotes-repeated-v1 parse syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        69 |        69 |        69 |        69 |        69 |        69 |        69 |        58 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        58 |
| Time (wall clock) (μs) *    |     86434 |     86901 |     87163 |     88211 |     89457 |     90166 |     90166 |        58 |

### GMSetzer footnotes-repeated-v1 parse syntax-on 64 KiB (bytes: 65538, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        17 |        17 |        17 |        17 |        17 |        17 |        17 |       239 |
| Malloc (total) (K) *        |        46 |        46 |        46 |        46 |        46 |        46 |        46 |       239 |
| Time (wall clock) (μs) *    |     20017 |     20726 |     20791 |     20857 |     21348 |     23593 |     23789 |       239 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-off 16 KiB (bytes: 16398, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5521 |      5521 |      5526 |      5526 |      5526 |      5526 |      5571 |       626 |
| Malloc (total) (K) *        |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       626 |
| Time (wall clock) (μs) *    |      7518 |      7881 |      7930 |      7995 |      8184 |      8856 |     11336 |       626 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        95 |        95 |        95 |        95 |        95 |        95 |        95 |        38 |
| Malloc (total) (K) *        |       332 |       332 |       332 |       332 |       332 |       332 |       332 |        38 |
| Time (wall clock) (μs) *    |    129514 |    131138 |    131662 |    132317 |    134349 |    135079 |    135079 |        38 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-off 64 KiB (bytes: 65538, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        23 |        23 |        23 |        23 |        23 |        23 |        23 |       156 |
| Malloc (total) (K) *        |        83 |        83 |        83 |        83 |        83 |        83 |        83 |       156 |
| Time (wall clock) (μs) *    |     31641 |     31801 |     31883 |     32358 |     32834 |     34308 |     34444 |       156 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 16 KiB (bytes: 16398, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6178 |      6181 |      6181 |      6181 |      6181 |      6185 |      6227 |       576 |
| Malloc (total) (K) *        |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       576 |
| Time (wall clock) (μs) *    |      8209 |      8360 |      8684 |      8847 |      9011 |      9863 |     11748 |       576 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       106 |       106 |       106 |       106 |       106 |       106 |       106 |        35 |
| Malloc (total) (K) *        |       332 |       332 |       332 |       332 |       332 |       332 |       332 |        35 |
| Time (wall clock) (μs) *    |    142042 |    142868 |    143262 |    145490 |    146538 |    148414 |    148414 |        35 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 64 KiB (bytes: 65538, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        26 |        26 |        26 |        26 |        26 |        26 |        26 |       142 |
| Malloc (total) (K) *        |        83 |        83 |        83 |        83 |        83 |        83 |        83 |       142 |
| Time (wall clock) (μs) *    |     34390 |     34832 |     35062 |     35258 |     36110 |     38044 |     40152 |       142 |

### GMSetzer invalid-utf8-v1 parse syntax-off 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      5854 |
| Malloc (total) *            |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      5854 |
| Time (wall clock) (μs) *    |       837 |       841 |       842 |       844 |       870 |      1004 |      3925 |      5854 |

### GMSetzer invalid-utf8-v1 parse syntax-off 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       341 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       341 |
| Time (wall clock) (μs) *    |     14536 |     14574 |     14590 |     14623 |     14852 |     17138 |     18028 |       341 |

### GMSetzer invalid-utf8-v1 parse syntax-off 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      1284 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      1284 |
| Time (wall clock) (μs) *    |      3832 |      3842 |      3850 |      3883 |      3955 |      4579 |      6857 |      1284 |

### GMSetzer invalid-utf8-v1 parse syntax-on 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      1285 |      5837 |
| Malloc (total) *            |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      2739 |      5837 |
| Time (wall clock) (μs) *    |       838 |       843 |       844 |       846 |       872 |       997 |      3734 |      5837 |

### GMSetzer invalid-utf8-v1 parse syntax-on 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       338 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       338 |
| Time (wall clock) (μs) *    |     14635 |     14696 |     14713 |     14746 |     14901 |     16859 |     18284 |       338 |

### GMSetzer invalid-utf8-v1 parse syntax-on 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      5135 |      1285 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      1285 |
| Time (wall clock) (μs) *    |      3828 |      3842 |      3846 |      3883 |      3949 |      4649 |      6663 |      1285 |

### GMSetzer long-emphasis-v1 parse syntax-off 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2108 |      2108 |      2108 |      2108 |      2108 |      2108 |      2108 |      4726 |
| Malloc (total) *            |        30 |        30 |        30 |        30 |        30 |        30 |        30 |      4726 |
| Time (wall clock) (μs) *    |       946 |      1042 |      1044 |      1048 |      1075 |      1200 |      4229 |      4726 |

### GMSetzer long-emphasis-v1 parse syntax-off 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        41 |        41 |        41 |        41 |        41 |        41 |        41 |       450 |
| Malloc (total) *            |        34 |        34 |        34 |        34 |        34 |        34 |        34 |       450 |
| Time (wall clock) (μs) *    |     10657 |     11026 |     11043 |     11059 |     11117 |     12755 |     14462 |       450 |

### GMSetzer long-emphasis-v1 parse syntax-off 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      9887 |      9887 |      9887 |      9887 |      9887 |      9887 |      9887 |      2363 |
| Malloc (total) *            |        32 |        32 |        32 |        32 |        32 |        32 |        32 |      2363 |
| Time (wall clock) (μs) *    |      2036 |      2044 |      2047 |      2052 |      2066 |      5157 |      6287 |      2363 |

### GMSetzer long-emphasis-v1 parse syntax-on 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3420 |      3420 |      3420 |      3420 |      3420 |      3420 |      3420 |      3062 |
| Malloc (total) *            |        60 |        60 |        60 |        60 |        60 |        60 |        60 |      3062 |
| Time (wall clock) (μs) *    |      1142 |      1605 |      1607 |      1613 |      1649 |      1951 |      6115 |      3062 |

### GMSetzer long-emphasis-v1 parse syntax-on 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        62 |        62 |        62 |        62 |        62 |        62 |        62 |       278 |
| Malloc (total) *            |        72 |        72 |        72 |        72 |        72 |        72 |        72 |       278 |
| Time (wall clock) (μs) *    |     17843 |     17891 |     17908 |     17940 |     18301 |     20677 |     20909 |       278 |

### GMSetzer long-emphasis-v1 parse syntax-on 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        15 |        15 |        15 |        15 |        15 |        15 |        15 |      1029 |
| Malloc (total) *            |        66 |        66 |        66 |        66 |        66 |        66 |        66 |      1029 |
| Time (wall clock) (μs) *    |      4767 |      4801 |      4809 |      4825 |      4887 |      5566 |      7619 |      1029 |

### GMSetzer m5-composed-v1 parse syntax-off 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      4271 |      4276 |      4279 |      4279 |      4279 |      4279 |      4279 |       896 |
| Malloc (total) (K) *        |        18 |        18 |        18 |        18 |        18 |        19 |        19 |       896 |
| Time (wall clock) (μs) *    |      5462 |      5501 |      5521 |      5579 |      5714 |      6447 |      9620 |       896 |

### GMSetzer m5-composed-v1 parse syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        66 |        66 |        66 |        66 |        66 |        66 |        66 |        59 |
| Malloc (total) (K) *        |       283 |       283 |       284 |       284 |       284 |       284 |       284 |        59 |
| Time (wall clock) (μs) *    |     84532 |     84869 |     85262 |     86311 |     87163 |     91641 |     91641 |        59 |

### GMSetzer m5-composed-v1 parse syntax-off 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        17 |        17 |        17 |        17 |        17 |        17 |        17 |       244 |
| Malloc (total) (K) *        |        71 |        72 |        72 |        72 |        72 |        72 |        72 |       244 |
| Time (wall clock) (μs) *    |     19550 |     20414 |     20480 |     20529 |     20824 |     23069 |     24335 |       244 |

### GMSetzer m5-composed-v1 parse syntax-on 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6242 |      6255 |      6258 |      6258 |      6258 |      6258 |      6258 |       559 |
| Malloc (total) (K) *        |        19 |        19 |        19 |        19 |        19 |        19 |        19 |       559 |
| Time (wall clock) (μs) *    |      8616 |      8733 |      8839 |      9028 |      9208 |     10346 |     11835 |       559 |

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        98 |        98 |        98 |        98 |        98 |        98 |        98 |        35 |
| Malloc (total) (K) *        |       285 |       286 |       286 |       286 |       286 |       286 |       286 |        35 |
| Time (wall clock) (μs) *    |    144820 |    145359 |    145883 |    147194 |    148505 |    153861 |    153861 |        35 |

### GMSetzer m5-composed-v1 parse syntax-on 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        25 |        25 |        25 |        25 |        25 |        25 |        25 |       144 |
| Malloc (total) (K) *        |        72 |        72 |        72 |        72 |        72 |        72 |        72 |       144 |
| Time (wall clock) (μs) *    |     33981 |     34275 |     34570 |     34800 |     35979 |     37290 |     37787 |       144 |

### GMSetzer m5-composed-v1 parse-render syntax-off 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      5253 |      5267 |      5272 |      5272 |      5280 |      5281 |      5281 |       688 |
| Malloc (total) (K) *        |        29 |        30 |        30 |        30 |        30 |        30 |        30 |       688 |
| Time (wall clock) (μs) *    |      7104 |      7164 |      7188 |      7229 |      7459 |      8327 |     10317 |       688 |

### GMSetzer m5-composed-v1 parse-render syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        82 |        82 |        82 |        82 |        82 |        82 |        82 |        43 |
| Malloc (total) (K) *        |       453 |       454 |       454 |       454 |       454 |       454 |       454 |        43 |
| Time (wall clock) (μs) *    |    114987 |    115540 |    115999 |    117768 |    118948 |    123334 |    123334 |        43 |

### GMSetzer m5-composed-v1 parse-render syntax-off 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        21 |        21 |        21 |        21 |        21 |        21 |        21 |       181 |
| Malloc (total) (K) *        |       114 |       114 |       115 |       115 |       115 |       115 |       115 |       181 |
| Time (wall clock) (μs) *    |     26915 |     27394 |     27509 |     27935 |     28377 |     31588 |     33876 |       181 |

### GMSetzer m5-composed-v1 parse-render syntax-on 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      7232 |      7250 |      7254 |      7254 |      7254 |      7254 |      7258 |       455 |
| Malloc (total) (K) *        |        30 |        30 |        30 |        30 |        30 |        30 |        30 |       455 |
| Time (wall clock) (μs) *    |     10548 |     10887 |     10928 |     11010 |     11338 |     12337 |     12951 |       455 |

### GMSetzer m5-composed-v1 parse-render syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       113 |       113 |       113 |       113 |       113 |       113 |       113 |        29 |
| Malloc (total) (K) *        |       458 |       459 |       459 |       459 |       459 |       459 |       459 |        29 |
| Time (wall clock) (μs) *    |    175305 |    176554 |    177209 |    178258 |    179438 |    188492 |    188492 |        29 |

### GMSetzer m5-composed-v1 parse-render syntax-on 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        28 |        28 |        28 |        28 |        28 |        28 |        28 |       119 |
| Malloc (total) (K) *        |       116 |       116 |       116 |       116 |       116 |       116 |       116 |       119 |
| Time (wall clock) (μs) *    |     41466 |     42041 |     42140 |     42271 |     43713 |     44958 |     45052 |       119 |

### GMSetzer open-brackets-v1 parse syntax-off 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6642 |      6642 |      6642 |      6642 |      6642 |      6642 |      6642 |      1403 |
| Malloc (total) *            |        43 |        43 |        43 |        43 |        43 |        43 |        43 |      1403 |
| Time (wall clock) (μs) *    |      3496 |      3516 |      3523 |      3535 |      3596 |      4151 |      6304 |      1403 |

### GMSetzer open-brackets-v1 parse syntax-off 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       114 |       114 |       114 |       114 |       114 |       114 |       114 |       131 |
| Malloc (total) *            |        51 |        51 |        51 |        51 |        51 |        51 |        51 |       131 |
| Time (wall clock) (μs) *    |     37896 |     37978 |     38011 |     38175 |     39256 |     41058 |     42282 |       131 |

### GMSetzer open-brackets-v1 parse syntax-off 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        28 |        28 |        28 |        28 |        28 |        28 |        28 |       456 |
| Malloc (total) *            |        47 |        47 |        47 |        47 |        47 |        47 |        47 |       456 |
| Time (wall clock) (μs) *    |     10869 |     10904 |     10912 |     10928 |     10977 |     12509 |     13691 |       456 |

### GMSetzer open-brackets-v1 parse syntax-on 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6642 |      6642 |      6642 |      6642 |      6642 |      6642 |      6642 |      1370 |
| Malloc (total) *            |        43 |        43 |        43 |        43 |        43 |        43 |        43 |      1370 |
| Time (wall clock) (μs) *    |      3583 |      3604 |      3613 |      3623 |      3660 |      4289 |      6534 |      1370 |

### GMSetzer open-brackets-v1 parse syntax-on 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       114 |       114 |       114 |       114 |       114 |       114 |       114 |       124 |
| Malloc (total) *            |        51 |        51 |        51 |        51 |        51 |        51 |        51 |       124 |
| Time (wall clock) (μs) *    |     40095 |     40239 |     40272 |     40403 |     41550 |     44302 |     44545 |       124 |

### GMSetzer open-brackets-v1 parse syntax-on 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        28 |        28 |        28 |        28 |        28 |        28 |        28 |       441 |
| Malloc (total) *            |        47 |        47 |        47 |        47 |        47 |        47 |        47 |       441 |
| Time (wall clock) (μs) *    |     11219 |     11256 |     11280 |     11305 |     11436 |     12812 |     14860 |       441 |

### GMSetzer quote-overflow-v1 parse syntax-off 16 KiB (bytes: 16576, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3657 |      3657 |      3657 |      3657 |      3657 |      3657 |      3657 |      5407 |
| Malloc (total) *            |        85 |        85 |        85 |        85 |        85 |        85 |        85 |      5407 |
| Time (wall clock) (μs) *    |       905 |       911 |       913 |       916 |       942 |      1043 |      2737 |      5407 |

### GMSetzer quote-overflow-v1 parse syntax-off 256 KiB (bytes: 262626, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        57 |        57 |        57 |        57 |        57 |        57 |        57 |       294 |
| Malloc (total) *            |       571 |       571 |       571 |       571 |       571 |       571 |       571 |       294 |
| Time (wall clock) (μs) *    |     16863 |     16892 |     16925 |     16941 |     17121 |     19743 |     21399 |       294 |

### GMSetzer quote-overflow-v1 parse syntax-off 64 KiB (bytes: 65786, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        14 |        14 |        14 |        14 |        14 |        14 |        14 |      1285 |
| Malloc (total) *            |       185 |       185 |       185 |       185 |       185 |       185 |       185 |      1285 |
| Time (wall clock) (μs) *    |      3835 |      3850 |      3858 |      3869 |      3887 |      4485 |      6636 |      1285 |

### GMSetzer quote-overflow-v1 parse syntax-on 16 KiB (bytes: 16576, corpus: quote-overflow-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      4313 |      4313 |      4313 |      4313 |      4313 |      4313 |      4313 |      2741 |
| Malloc (total) *            |       111 |       111 |       111 |       111 |       111 |       111 |       111 |      2741 |
| Time (wall clock) (μs) *    |      1789 |      1797 |      1799 |      1812 |      1849 |      2177 |      5171 |      2741 |

### GMSetzer quote-overflow-v1 parse syntax-on 256 KiB (bytes: 262626, corpus: quote-overflow-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        68 |        68 |        68 |        68 |        68 |        68 |        68 |       222 |
| Malloc (total) *            |       605 |       605 |       605 |       605 |       605 |       605 |       605 |       222 |
| Time (wall clock) (μs) *    |     22307 |     22381 |     22413 |     22495 |     22921 |     25395 |     26697 |       222 |

### GMSetzer quote-overflow-v1 parse syntax-on 64 KiB (bytes: 65786, corpus: quote-overflow-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        17 |        17 |        17 |        17 |        17 |        17 |        17 |       845 |
| Malloc (total) *            |       215 |       215 |       215 |       215 |       215 |       215 |       215 |       845 |
| Time (wall clock) (μs) *    |      5834 |      5861 |      5874 |      5886 |      5919 |      6672 |      8663 |       845 |

### GMSetzer unmatched-backticks-v1 parse syntax-off 16 KiB (bytes: 16476, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       631 |       631 |       631 |       631 |       631 |       631 |       631 |     10000 |
| Malloc (total) *            |       387 |       387 |       387 |       387 |       387 |       387 |       387 |     10000 |
| Time (wall clock) (μs) *    |       148 |       150 |       150 |       152 |       154 |       196 |      2379 |     10000 |

### GMSetzer unmatched-backticks-v1 parse syntax-off 256 KiB (bytes: 262455, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1624 |      1624 |      1624 |      1624 |      1624 |      1624 |      1624 |      3759 |
| Malloc (total) *            |      1477 |      1477 |      1477 |      1477 |      1477 |      1477 |      1477 |      3759 |
| Time (wall clock) (μs) *    |      1303 |      1310 |      1313 |      1319 |      1353 |      1578 |      4571 |      3759 |

### GMSetzer unmatched-backticks-v1 parse syntax-off 64 KiB (bytes: 65708, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       864 |       864 |       864 |       864 |       864 |       864 |       864 |     10000 |
| Malloc (total) *            |       751 |       751 |       751 |       751 |       751 |       751 |       751 |     10000 |
| Time (wall clock) (μs) *    |       359 |       361 |       364 |       366 |       377 |       454 |      3163 |     10000 |

### GMSetzer unmatched-backticks-v1 parse syntax-on 16 KiB (bytes: 16476, corpus: unmatched-backticks-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       631 |       631 |       631 |       631 |       631 |       631 |       631 |     10000 |
| Malloc (total) *            |       387 |       387 |       387 |       387 |       387 |       387 |       387 |     10000 |
| Time (wall clock) (μs) *    |       149 |       150 |       151 |       151 |       154 |       190 |      2905 |     10000 |

### GMSetzer unmatched-backticks-v1 parse syntax-on 256 KiB (bytes: 262455, corpus: unmatched-backticks-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1624 |      1624 |      1624 |      1624 |      1624 |      1624 |      1624 |      3757 |
| Malloc (total) *            |      1477 |      1477 |      1477 |      1477 |      1477 |      1477 |      1477 |      3757 |
| Time (wall clock) (μs) *    |      1307 |      1314 |      1316 |      1321 |      1354 |      1561 |      3673 |      3757 |

### GMSetzer unmatched-backticks-v1 parse syntax-on 64 KiB (bytes: 65708, corpus: unmatched-backticks-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       864 |       864 |       864 |       864 |       864 |       864 |       864 |     10000 |
| Malloc (total) *            |       751 |       751 |       751 |       751 |       751 |       751 |       751 |     10000 |
| Time (wall clock) (μs) *    |       363 |       366 |       367 |       369 |       372 |       424 |      1879 |     10000 |

### cmark-gfm (C) invalid-utf8-v1 parse 16 KiB (bytes: 16388, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       574 |       574 |       574 |       574 |       574 |       574 |       574 |     10000 |
| Malloc (total) *            |      2757 |      2757 |      2757 |      2757 |      2757 |      2757 |      2757 |     10000 |
| Time (wall clock) (μs) *    |       315 |       318 |       320 |       322 |       328 |       389 |      1776 |     10000 |

### cmark-gfm (C) invalid-utf8-v1 parse 256 KiB (bytes: 262148, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      9249 |      9249 |      9249 |      9249 |      9249 |      9249 |      9249 |       833 |
| Malloc (total) (K) *        |        44 |        44 |        44 |        44 |        44 |        44 |        44 |       833 |
| Time (wall clock) (μs) *    |      5750 |      5800 |      6074 |      6115 |      6156 |      6869 |      8891 |       833 |

### cmark-gfm (C) invalid-utf8-v1 parse 64 KiB (bytes: 65540, corpus: invalid-utf8-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2250 |      2250 |      2250 |      2250 |      2250 |      2250 |      2250 |      3865 |
| Malloc (total) (K) *        |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      3865 |
| Time (wall clock) (μs) *    |      1260 |      1274 |      1279 |      1285 |      1317 |      1511 |      4444 |      3865 |

### cmark-gfm (C) long-emphasis-v1 parse 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       806 |       806 |       806 |       806 |       806 |       806 |       806 |     10000 |
| Malloc (total) *            |      4119 |      4119 |      4119 |      4119 |      4119 |      4119 |      4119 |     10000 |
| Time (wall clock) (μs) *    |       441 |       444 |       445 |       447 |       456 |       516 |      3319 |     10000 |

### cmark-gfm (C) long-emphasis-v1 parse 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        13 |        13 |        13 |        13 |        13 |        13 |        13 |       498 |
| Malloc (total) (K) *        |        66 |        66 |        66 |        66 |        66 |        66 |        66 |       498 |
| Time (wall clock) (μs) *    |      9657 |      9781 |      9830 |     10338 |     10510 |     11362 |     13277 |       498 |

### cmark-gfm (C) long-emphasis-v1 parse 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3214 |      3214 |      3214 |      3214 |      3214 |      3214 |      3214 |      2643 |
| Malloc (total) (K) *        |        16 |        16 |        16 |        16 |        16 |        16 |        16 |      2643 |
| Time (wall clock) (μs) *    |      1778 |      1792 |      1817 |      1881 |      2152 |      2419 |      5675 |      2643 |

### cmark-gfm (C) open-brackets-v1 parse 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3672 |      3672 |      3672 |      3672 |      3672 |      3672 |      3672 |      2102 |
| Malloc (total) (K) *        |        33 |        33 |        33 |        33 |        33 |        33 |        33 |      2102 |
| Time (wall clock) (μs) *    |      2317 |      2335 |      2343 |      2398 |      2417 |      2867 |      5211 |      2102 |

### cmark-gfm (C) open-brackets-v1 parse 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        59 |        59 |        59 |        59 |        59 |        59 |        59 |       118 |
| Malloc (total) (K) *        |       524 |       524 |       524 |       524 |       524 |       524 |       524 |       118 |
| Time (wall clock) (μs) *    |     41884 |     42107 |     42205 |     42336 |     43352 |     44171 |     46489 |       118 |

### cmark-gfm (C) open-brackets-v1 parse 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        15 |        15 |        15 |        15 |        15 |        15 |        15 |       475 |
| Malloc (total) (K) *        |       131 |       131 |       131 |       131 |       131 |       131 |       131 |       475 |
| Time (wall clock) (μs) *    |     10397 |     10453 |     10486 |     10510 |     10682 |     11764 |     11940 |       475 |

### cmark-gfm (C) quote-overflow-v1 parse 16 KiB (bytes: 16576, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1982 |      1982 |      1982 |      1982 |      1982 |      1982 |      1982 |      3812 |
| Malloc (total) (K) *        |        16 |        16 |        16 |        16 |        16 |        16 |        16 |      3812 |
| Time (wall clock) (μs) *    |      1280 |      1285 |      1291 |      1317 |      1338 |      1551 |      5414 |      3812 |

### cmark-gfm (C) quote-overflow-v1 parse 256 KiB (bytes: 262626, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        31 |        31 |        31 |        31 |        31 |        31 |        31 |       182 |
| Malloc (total) (K) *        |       261 |       261 |       261 |       261 |       261 |       261 |       261 |       182 |
| Time (wall clock) (μs) *    |     26725 |     26952 |     27640 |     27787 |     28099 |     31277 |     31756 |       182 |

### cmark-gfm (C) quote-overflow-v1 parse 64 KiB (bytes: 65786, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      7859 |      7859 |      7859 |      7859 |      7859 |      7859 |      7859 |       776 |
| Malloc (total) (K) *        |        65 |        65 |        65 |        65 |        65 |        65 |        65 |       776 |
| Time (wall clock) (μs) *    |      6224 |      6324 |      6377 |      6476 |      6550 |      7516 |      9252 |       776 |

### cmark-gfm (C) unmatched-backticks-v1 parse 16 KiB (bytes: 16476, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       197 |       197 |       197 |       197 |       197 |       197 |       197 |     10000 |
| Malloc (total) *            |       393 |       393 |       393 |       393 |       393 |       393 |       393 |     10000 |
| Time (wall clock) (μs) *    |        55 |        56 |        56 |        57 |        58 |        70 |      1706 |     10000 |

### cmark-gfm (C) unmatched-backticks-v1 parse 256 KiB (bytes: 262455, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2420 |      2420 |      2420 |      2420 |      2420 |      2420 |      2420 |      4830 |
| Malloc (total) *            |      1486 |      1486 |      1486 |      1486 |      1486 |      1486 |      1486 |      4830 |
| Time (wall clock) (μs) *    |       675 |      1021 |      1023 |      1026 |      1054 |      1180 |      3988 |      4830 |

### cmark-gfm (C) unmatched-backticks-v1 parse 64 KiB (bytes: 65708, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       715 |       715 |       715 |       715 |       715 |       715 |       715 |     10000 |
| Malloc (total) *            |       759 |       759 |       759 |       759 |       759 |       759 |       759 |     10000 |
| Time (wall clock) (μs) *    |       159 |       160 |       161 |       162 |       165 |       194 |      3049 |     10000 |

