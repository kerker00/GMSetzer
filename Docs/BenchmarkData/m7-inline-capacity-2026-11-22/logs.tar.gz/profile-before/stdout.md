
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer open-brackets-v1 parse syntax-off 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       174 |       174 |       174 |       174 |       174 |       174 |       174 |       299 |
| Malloc (total) *            |        76 |        76 |        76 |        76 |        76 |        76 |        76 |       299 |

### Allocations: HardeningBenchmarks:GMSetzer open-brackets-v1 parse syntax-off 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

299 iterations, 22,724 allocations (76.0/iteration), 52.1 GB, 21 unique stacks

**#1  8,372 allocations (28.0/iteration), 36.8%, 24.1 GB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.append(_:range:segments:fallbackLiteral:to:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#2  7,176 allocations (24.0/iteration), 31.6%, 27.6 GB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  InlineParser.parse() in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#3  598 allocations (2.0/iteration), 2.6%, 78.4 MB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized InlineInput.init(_:children:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#4  598 allocations (2.0/iteration), 2.6%, 406.6 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.reserveCapacity(_:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#5  598 allocations (2.0/iteration), 2.6%, 191.4 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.append(_:range:segments:fallbackLiteral:to:) in HardeningBenchmarks
    2  BlockParser.appendText(_:to:) in HardeningBenchmarks
    3  BlockParser.finishLeaf(headingLevel:closingLine:tablePreamble:) in HardeningBenchmarks
    4  BlockParser.parse() in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#6  598 allocations (2.0/iteration), 2.6%, 105.2 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.reserveCapacity(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#7  598 allocations (2.0/iteration), 2.6%, 67.0 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#8  299 allocations (1.0/iteration), 1.3%, 176.4 MB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  InlineParser.reset(to:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#9  299 allocations (1.0/iteration), 1.3%, 78.4 MB**
```
    0  closure #1 in BlockParser.decode(_:) in HardeningBenchmarks
    1  BlockParser.appendText(_:to:) in HardeningBenchmarks
    2  BlockParser.finishLeaf(headingLevel:closingLine:tablePreamble:) in HardeningBenchmarks
    3  BlockParser.parse() in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#10  299 allocations (1.0/iteration), 1.3%, 78.4 MB**
```
    0  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    1  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#11  299 allocations (1.0/iteration), 1.3%, 315.7 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    4  BlockParser.parse() in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#12  299 allocations (1.0/iteration), 1.3%, 315.7 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    4  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#13  299 allocations (1.0/iteration), 1.3%, 47.8 KB**
```
    0  DocumentBuilder.init(source:collectSyntaxDetails:) in HardeningBenchmarks
    1  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    2  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    3  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#14  299 allocations (1.0/iteration), 1.3%, 47.8 KB**
```
    0  DocumentBuilder.init(source:collectSyntaxDetails:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#15  299 allocations (1.0/iteration), 1.3%, 45.4 KB**
```
    0  InlineParser.emphasis(bottom:) in HardeningBenchmarks
    1  InlineParser.parse() in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#16  299 allocations (1.0/iteration), 1.3%, 33.5 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized static BlockParser.scanLines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#17  299 allocations (1.0/iteration), 1.3%, 16.7 KB**
```
    0  specialized Array.init(repeating:count:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#18  299 allocations (1.0/iteration), 1.3%, 14.4 KB**
```
    0  specialized _ContiguousArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized ContiguousArray._createNewBuffer(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#19  299 allocations (1.0/iteration), 1.3%, 12.0 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  Document.children(of:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#20  299 allocations (1.0/iteration), 1.3%, 12.0 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  Document.children(of:into:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#21  299 allocations (1.0/iteration), 1.3%, 10.5 KB**
```
    0  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    1  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  BlockParser.parse() in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

Writing to /private/tmp/gmsetzer-m7-capacity-4hmp9_ep/profile-before/HardeningBenchmarks.GMSetzer_open-brackets-v1_parse_syntax-off_256_KiB_(bytes:_262144,_corpus:_open-brackets-v1,_profile:_commonmark,_syntax:_off).allocations.json
