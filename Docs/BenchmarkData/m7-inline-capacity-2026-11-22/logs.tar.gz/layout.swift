@testable import SetzerParser
import SetzerSyntax
print("Item", MemoryLayout<InlineParser.Item>.stride)
print("Bracket", MemoryLayout<InlineParser.Bracket>.stride)
print("Node", MemoryLayout<Node>.stride)
