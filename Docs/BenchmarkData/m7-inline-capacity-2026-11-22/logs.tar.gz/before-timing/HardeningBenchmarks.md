
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer long-emphasis-v1 parse syntax-on 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      3951 |      3951 |      3951 |      3951 |      3951 |      3951 |      3951 |     10000 |
| Malloc (total) *            |        74 |        74 |        74 |        74 |        74 |        74 |        74 |     10000 |
| Time (wall clock) (μs) *    |       416 |       429 |       439 |       458 |       479 |       948 |      3031 |     10000 |

### GMSetzer long-emphasis-v1 parse syntax-on 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        76 |        76 |        76 |        76 |        76 |        76 |        76 |       628 |
| Malloc (total) *            |        94 |        94 |        94 |        94 |        94 |        94 |        94 |       628 |
| Time (wall clock) (μs) *    |      7212 |      7483 |      7643 |      7999 |      8643 |     12730 |     16273 |       628 |

### GMSetzer long-emphasis-v1 parse syntax-on 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        18 |        18 |        18 |        18 |        18 |        18 |        18 |      2828 |
| Malloc (total) *            |        84 |        84 |        84 |        84 |        84 |        84 |        84 |      2828 |
| Time (wall clock) (μs) *    |      1693 |      1730 |      1758 |      1794 |      1830 |      1950 |      2837 |      2828 |

### GMSetzer m5-composed-v1 parse syntax-on 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6396 |      6396 |      6396 |      6396 |      6396 |      6396 |      6396 |       820 |
| Malloc (total) (K) *        |        17 |        17 |        17 |        17 |        17 |        17 |        17 |       820 |
| Time (wall clock) (μs) *    |      5887 |      6025 |      6087 |      6152 |      6226 |      6455 |      7401 |       820 |

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       101 |       101 |       101 |       101 |       101 |       101 |       101 |        53 |
| Malloc (total) (K) *        |       262 |       262 |       262 |       262 |       262 |       262 |       262 |        53 |
| Time (wall clock) (μs) *    |     93656 |     94568 |     95224 |     96207 |     99484 |    107668 |    107668 |        53 |

### GMSetzer m5-composed-v1 parse syntax-on 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        25 |        25 |        25 |        25 |        25 |        25 |        25 |       213 |
| Malloc (total) (K) *        |        66 |        66 |        66 |        66 |        66 |        66 |        66 |       213 |
| Time (wall clock) (μs) *    |     23014 |     23396 |     23527 |     23658 |     23871 |     24773 |     25741 |       213 |

### GMSetzer open-brackets-v1 parse syntax-off 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      5187 |
| Malloc (total) *            |        63 |        63 |        63 |        63 |        63 |        63 |        63 |      5187 |
| Time (wall clock) (μs) *    |       910 |       934 |       949 |       976 |      1008 |      1087 |      4987 |      5187 |

### GMSetzer open-brackets-v1 parse syntax-off 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       174 |       174 |       174 |       174 |       174 |       174 |       174 |       304 |
| Malloc (total) *            |        76 |        76 |        76 |        76 |        76 |        76 |        76 |       304 |
| Time (wall clock) (μs) *    |     15581 |     16081 |     16269 |     16572 |     17252 |     20840 |     22804 |       304 |

### GMSetzer open-brackets-v1 parse syntax-off 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        44 |        44 |        44 |        44 |        44 |        44 |        44 |      1035 |
| Malloc (total) *            |        70 |        70 |        70 |        70 |        70 |        70 |        70 |      1035 |
| Time (wall clock) (μs) *    |      3872 |      4049 |      4207 |      4796 |      6341 |     13050 |     29524 |      1035 |

### GMSetzer open-brackets-v1 parse syntax-on 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      4420 |
| Malloc (total) *            |        63 |        63 |        63 |        63 |        63 |        63 |        63 |      4420 |
| Time (wall clock) (μs) *    |      1027 |      1097 |      1117 |      1141 |      1187 |      1462 |      3567 |      4420 |

### GMSetzer open-brackets-v1 parse syntax-on 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       174 |       174 |       174 |       174 |       174 |       174 |       174 |       281 |
| Malloc (total) *            |        76 |        76 |        76 |        76 |        76 |        76 |        76 |       281 |
| Time (wall clock) (μs) *    |     17279 |     17678 |     17809 |     17924 |     18055 |     18481 |     20198 |       281 |

### GMSetzer open-brackets-v1 parse syntax-on 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        44 |        44 |        44 |        44 |        44 |        44 |        44 |      1050 |
| Malloc (total) *            |        70 |        70 |        70 |        70 |        70 |        70 |        70 |      1050 |
| Time (wall clock) (μs) *    |      4200 |      4407 |      4481 |      4608 |      5063 |      8897 |     50742 |      1050 |

