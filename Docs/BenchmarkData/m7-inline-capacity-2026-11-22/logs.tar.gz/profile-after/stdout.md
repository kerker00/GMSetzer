
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer open-brackets-v1 parse syntax-off 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       120 |       120 |       120 |       120 |       120 |       120 |       120 |       302 |
| Malloc (total) *            |        51 |        51 |        51 |        51 |        51 |        51 |        51 |       302 |

### Allocations: HardeningBenchmarks:GMSetzer open-brackets-v1 parse syntax-off 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

302 iterations, 15,402 allocations (51.0/iteration), 36.2 GB, 22 unique stacks

**#1  5,738 allocations (19.0/iteration), 37.3%, 5.1 GB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  InlineParser.parse() in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#2  1,812 allocations (6.0/iteration), 11.8%, 19.3 GB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  InlineParser.append(_:_:_:) in HardeningBenchmarks
    2  InlineParser.parse() in HardeningBenchmarks
    3  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#3  604 allocations (2.0/iteration), 3.9%, 11.4 GB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.reserveAdditionalCapacity(_:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#4  604 allocations (2.0/iteration), 3.9%, 79.2 MB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized InlineInput.init(_:children:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#5  604 allocations (2.0/iteration), 3.9%, 410.7 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.reserveCapacity(_:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#6  604 allocations (2.0/iteration), 3.9%, 193.3 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.append(_:range:segments:fallbackLiteral:to:) in HardeningBenchmarks
    2  BlockParser.appendText(_:to:) in HardeningBenchmarks
    3  BlockParser.finishLeaf(headingLevel:closingLine:tablePreamble:) in HardeningBenchmarks
    4  BlockParser.parse() in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#7  604 allocations (2.0/iteration), 3.9%, 106.3 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  DocumentBuilder.reserveCapacity(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#8  604 allocations (2.0/iteration), 3.9%, 60.4 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#9  302 allocations (1.0/iteration), 2.0%, 148.4 MB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  InlineParser.reset(to:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#10  302 allocations (1.0/iteration), 2.0%, 79.2 MB**
```
    0  closure #1 in BlockParser.decode(_:) in HardeningBenchmarks
    1  BlockParser.appendText(_:to:) in HardeningBenchmarks
    2  BlockParser.finishLeaf(headingLevel:closingLine:tablePreamble:) in HardeningBenchmarks
    3  BlockParser.parse() in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#11  302 allocations (1.0/iteration), 2.0%, 79.2 MB**
```
    0  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    1  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#12  302 allocations (1.0/iteration), 2.0%, 318.9 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    4  BlockParser.parse() in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#13  302 allocations (1.0/iteration), 2.0%, 318.9 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    4  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    5  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    6  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    7  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#14  302 allocations (1.0/iteration), 2.0%, 48.3 KB**
```
    0  DocumentBuilder.init(source:collectSyntaxDetails:) in HardeningBenchmarks
    1  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    2  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    3  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#15  302 allocations (1.0/iteration), 2.0%, 48.3 KB**
```
    0  DocumentBuilder.init(source:collectSyntaxDetails:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#16  302 allocations (1.0/iteration), 2.0%, 45.9 KB**
```
    0  InlineParser.emphasis(bottom:) in HardeningBenchmarks
    1  InlineParser.parse() in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#17  302 allocations (1.0/iteration), 2.0%, 33.8 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized static BlockParser.scanLines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#18  302 allocations (1.0/iteration), 2.0%, 16.9 KB**
```
    0  specialized Array.init(repeating:count:) in HardeningBenchmarks
    1  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    2  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    3  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    4  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#19  302 allocations (1.0/iteration), 2.0%, 14.5 KB**
```
    0  specialized _ContiguousArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  specialized ContiguousArray._createNewBuffer(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#20  302 allocations (1.0/iteration), 2.0%, 12.1 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  Document.children(of:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#21  302 allocations (1.0/iteration), 2.0%, 12.1 KB**
```
    0  specialized _ArrayBuffer._consumeAndCreateNew(bufferIsUnique:minimumCapacity:growForAppend:) in HardeningBenchmarks
    1  Document.children(of:into:) in HardeningBenchmarks
    2  MarkdownParser.parseInlines(_:) in HardeningBenchmarks
    3  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    4  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    5  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

**#22  302 allocations (1.0/iteration), 2.0%, 10.6 KB**
```
    0  closure #1 in Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    1  specialized Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    2  Document.init(source:nodes:diagnostics:customLeafFallbacks:tokens:renderingPolicy:) in HardeningBenchmarks
    3  BlockParser.parse() in HardeningBenchmarks
    4  MarkdownParser.parse(bytes:) in HardeningBenchmarks
    5  closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
    6  partial apply for closure #1 in closure #1 in variable initialization expression of benchmarks in HardeningBenchmarks
```

Writing to /private/tmp/gmsetzer-m7-capacity-4hmp9_ep/profile-after/HardeningBenchmarks.GMSetzer_open-brackets-v1_parse_syntax-off_256_KiB_(bytes:_262144,_corpus:_open-brackets-v1,_profile:_commonmark,_syntax:_off).allocations.json
