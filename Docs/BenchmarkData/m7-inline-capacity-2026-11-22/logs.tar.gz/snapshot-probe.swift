import Foundation
import GMSetzer

struct Example: Decodable { let example: Int; let markdown: String }
struct RangeRecord: Codable { let lower: Int; let upper: Int }
struct TokenRecord: Codable { let role: String; let lower: Int; let upper: Int; let owner: Int }
struct NodeRecord: Codable { let data: String; let lower: Int; let upper: Int; let segments: [RangeRecord]; let firstChild: Int?; let nextSibling: Int? }
struct Record: Codable { let profile: String; let example: Int; let nodes: [NodeRecord]; let tokens: [TokenRecord] }
var records: [Record] = []
for (name, profile, path) in [("commonmark", Profile.commonMark, CommandLine.arguments[1]), ("gfm", Profile.gfm, CommandLine.arguments[2])] {
    let examples = try JSONDecoder().decode([Example].self, from: Data(contentsOf: URL(fileURLWithPath: path)))
    for example in examples {
        let document = MarkdownParser(profile: profile, collectSyntaxDetails: true).parse(example.markdown)
        let nodes = document.nodes.map { NodeRecord(data: String(reflecting: $0.data), lower: $0.range.lowerBound, upper: $0.range.upperBound, segments: $0.sourceSegments.map { RangeRecord(lower: $0.lowerBound, upper: $0.upperBound) }, firstChild: $0.firstChild, nextSibling: $0.nextSibling) }
        let tokens = document.tokens!.map { TokenRecord(role: $0.role, lower: $0.range.lowerBound, upper: $0.range.upperBound, owner: $0.owner) }
        records.append(Record(profile: name, example: example.example, nodes: nodes, tokens: tokens))
    }
}
let encoder = JSONEncoder()
encoder.outputFormatting = [.sortedKeys]
FileHandle.standardOutput.write(try encoder.encode(records))
