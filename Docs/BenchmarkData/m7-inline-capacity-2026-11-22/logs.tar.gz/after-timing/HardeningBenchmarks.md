
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer long-emphasis-v1 parse syntax-on 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2696 |      2696 |      2696 |      2696 |      2696 |      2696 |      2696 |     10000 |
| Malloc (total) *            |        58 |        58 |        58 |        58 |        58 |        58 |        58 |     10000 |
| Time (wall clock) (μs) *    |       391 |       406 |       407 |       410 |       424 |       467 |       526 |     10000 |

### GMSetzer long-emphasis-v1 parse syntax-on 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        51 |        51 |        51 |        51 |        51 |        51 |        51 |       729 |
| Malloc (total) *            |        70 |        70 |        70 |        70 |        70 |        70 |        70 |       729 |
| Time (wall clock) (μs) *    |      6663 |      6783 |      6828 |      6889 |      6984 |      7422 |      7934 |       729 |

### GMSetzer long-emphasis-v1 parse syntax-on 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        12 |        12 |        12 |        12 |        12 |        12 |        12 |      3042 |
| Malloc (total) *            |        64 |        64 |        64 |        64 |        64 |        64 |        64 |      3042 |
| Time (wall clock) (μs) *    |      1605 |      1625 |      1636 |      1653 |      1679 |      1753 |      1848 |      3042 |

### GMSetzer m5-composed-v1 parse syntax-on 16 KiB (bytes: 16654, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6395 |      6395 |      6395 |      6395 |      6395 |      6395 |      6395 |       842 |
| Malloc (total) (K) *        |        17 |        17 |        17 |        17 |        17 |        17 |        17 |       842 |
| Time (wall clock) (μs) *    |      5699 |      5894 |      5935 |      5984 |      6029 |      6152 |      6516 |       842 |

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       101 |       101 |       101 |       101 |       101 |       101 |       101 |        55 |
| Malloc (total) (K) *        |       262 |       262 |       262 |       262 |       262 |       262 |       262 |        55 |
| Time (wall clock) (μs) *    |     90142 |     90636 |     91030 |     91357 |     91881 |     93105 |     93105 |        55 |

### GMSetzer m5-composed-v1 parse syntax-on 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        25 |        25 |        25 |        25 |        25 |        25 |        25 |       216 |
| Malloc (total) (K) *        |        66 |        66 |        66 |        66 |        66 |        66 |        66 |       216 |
| Time (wall clock) (μs) *    |     22739 |     23052 |     23183 |     23298 |     23413 |     23806 |     24932 |       216 |

### GMSetzer open-brackets-v1 parse syntax-off 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6984 |      6984 |      6984 |      6984 |      6984 |      6984 |      6984 |      5216 |
| Malloc (total) *            |        43 |        43 |        43 |        43 |        43 |        43 |        43 |      5216 |
| Time (wall clock) (μs) *    |       930 |       946 |       951 |       964 |       985 |      1055 |      1168 |      5216 |

### GMSetzer open-brackets-v1 parse syntax-off 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       120 |       120 |       120 |       120 |       120 |       120 |       120 |       316 |
| Malloc (total) *            |        51 |        51 |        51 |        51 |        51 |        51 |        51 |       316 |
| Time (wall clock) (μs) *    |     15602 |     15778 |     15843 |     15909 |     15983 |     16474 |     17021 |       316 |

### GMSetzer open-brackets-v1 parse syntax-off 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        30 |        30 |        30 |        30 |        30 |        30 |        30 |      1272 |
| Malloc (total) *            |        47 |        47 |        47 |        47 |        47 |        47 |        47 |      1272 |
| Time (wall clock) (μs) *    |      3822 |      3865 |      3893 |      3949 |      4020 |      4227 |     18292 |      1272 |

### GMSetzer open-brackets-v1 parse syntax-on 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6984 |      6984 |      6984 |      6984 |      6984 |      6984 |      6984 |      4616 |
| Malloc (total) *            |        43 |        43 |        43 |        43 |        43 |        43 |        43 |      4616 |
| Time (wall clock) (μs) *    |      1049 |      1067 |      1074 |      1089 |      1117 |      1186 |      1245 |      4616 |

### GMSetzer open-brackets-v1 parse syntax-on 256 KiB (bytes: 262144, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       120 |       120 |       120 |       120 |       120 |       120 |       120 |       280 |
| Malloc (total) *            |        51 |        51 |        51 |        51 |        51 |        51 |        51 |       280 |
| Time (wall clock) (μs) *    |     17595 |     17793 |     17875 |     17957 |     18022 |     18416 |     18500 |       280 |

### GMSetzer open-brackets-v1 parse syntax-on 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        30 |        30 |        30 |        30 |        30 |        30 |        30 |      1132 |
| Malloc (total) *            |        47 |        47 |        47 |        47 |        47 |        47 |        47 |      1132 |
| Time (wall clock) (μs) *    |      4318 |      4379 |      4407 |      4452 |      4502 |      4604 |      5247 |      1132 |

