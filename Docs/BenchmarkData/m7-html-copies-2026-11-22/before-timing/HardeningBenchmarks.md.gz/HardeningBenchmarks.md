
## Baseline 'Current_run'

```
Host 'BlackBook.local' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer footnotes-repeated-v1 parse syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        51 |        59 |        59 |        59 |        59 |        59 |        59 |       107 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |       107 |
| Time (wall clock) (μs) *    |     46218 |     46432 |     46596 |     46825 |     47055 |     50004 |     51586 |       107 |

### GMSetzer footnotes-repeated-v1 parse syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        72 |        72 |        72 |        72 |        72 |        72 |        72 |        96 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        96 |
| Time (wall clock) (μs) *    |     51968 |     52396 |     52527 |     52756 |     52920 |     53997 |     53997 |        96 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        95 |        95 |        95 |        95 |        95 |        95 |        95 |        62 |
| Malloc (total) (K) *        |       332 |       332 |       332 |       332 |       332 |       332 |       332 |        62 |
| Time (wall clock) (μs) *    |     80304 |     80871 |     81461 |     81789 |     82313 |     84382 |     84382 |        62 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       108 |       108 |       108 |       108 |       108 |       108 |       108 |        57 |
| Malloc (total) (K) *        |       332 |       332 |       332 |       332 |       332 |       332 |       332 |        57 |
| Time (wall clock) (μs) *    |     87660 |     88343 |     88867 |     89326 |     89588 |     94184 |     94184 |        57 |

### GMSetzer m5-composed-v1 parse syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        65 |        65 |        65 |        65 |        65 |        65 |        65 |        94 |
| Malloc (total) (K) *        |       260 |       260 |       260 |       260 |       260 |       260 |       260 |        94 |
| Time (wall clock) (μs) *    |     53110 |     53314 |     53412 |     53510 |     53576 |     57591 |     57591 |        94 |

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       101 |       101 |       101 |       101 |       101 |       101 |       101 |        56 |
| Malloc (total) (K) *        |       262 |       262 |       262 |       262 |       262 |       262 |       262 |        56 |
| Time (wall clock) (μs) *    |     89233 |     89850 |     90046 |     90243 |     90440 |     91052 |     91052 |        56 |

### GMSetzer m5-composed-v1 parse-render syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        80 |        80 |        80 |        80 |        80 |        80 |        80 |        66 |
| Malloc (total) (K) *        |       422 |       422 |       422 |       422 |       422 |       422 |       422 |        66 |
| Time (wall clock) (μs) *    |     76003 |     76349 |     76546 |     76874 |     77332 |     80490 |     80490 |        66 |

### GMSetzer m5-composed-v1 parse-render syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       116 |       116 |       116 |       116 |       116 |       116 |       116 |        44 |
| Malloc (total) (K) *        |       424 |       424 |       424 |       424 |       424 |       424 |       424 |        44 |
| Time (wall clock) (μs) *    |    115443 |    115802 |    115999 |    116195 |    116457 |    117897 |    117897 |        44 |

