
## Baseline 'Current_run'

```
Host 'PowerG5' with 4 'x86_64' processors with 31 GB memory, running:
#1 SMP PREEMPT_DYNAMIC Fri, 13 Nov 2026 19:45:18 +0000
```
## HardeningBenchmarks

### GMSetzer footnotes-repeated-v1 parse syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        58 |        58 |        58 |        58 |        58 |        58 |        58 |        67 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        67 |
| Time (wall clock) (μs) *    |     74171 |     74514 |     74711 |     75170 |     76022 |     77587 |     77587 |        67 |

### GMSetzer footnotes-repeated-v1 parse syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        69 |        69 |        69 |        69 |        69 |        69 |        69 |        57 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        57 |
| Time (wall clock) (μs) *    |     87022 |     88211 |     88801 |     89129 |     90505 |     91382 |     91382 |        57 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        95 |        95 |        95 |        95 |        95 |        95 |        95 |        37 |
| Malloc (total) (K) *        |       332 |       332 |       332 |       332 |       332 |       332 |       332 |        37 |
| Time (wall clock) (μs) *    |    134367 |    135004 |    135660 |    136315 |    136708 |    137127 |    137127 |        37 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       106 |       106 |       106 |       106 |       106 |       106 |       106 |        35 |
| Malloc (total) (K) *        |       332 |       332 |       332 |       332 |       332 |       332 |       332 |        35 |
| Time (wall clock) (μs) *    |    141216 |    142082 |    142737 |    143393 |    144441 |    146874 |    146874 |        35 |

### GMSetzer m5-composed-v1 parse syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        66 |        66 |        66 |        66 |        66 |        66 |        66 |        59 |
| Malloc (total) (K) *        |       283 |       283 |       284 |       284 |       284 |       284 |       284 |        59 |
| Time (wall clock) (μs) *    |     84962 |     85328 |     85524 |     86245 |     87163 |     97960 |     97960 |        59 |

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        98 |        98 |        98 |        98 |        98 |        98 |        98 |        35 |
| Malloc (total) (K) *        |       285 |       285 |       286 |       286 |       286 |       286 |       286 |        35 |
| Time (wall clock) (μs) *    |    144530 |    145228 |    145490 |    146932 |    148242 |    152256 |    152256 |        35 |

### GMSetzer m5-composed-v1 parse-render syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        82 |        82 |        82 |        82 |        82 |        82 |        82 |        43 |
| Malloc (total) (K) *        |       453 |       454 |       454 |       454 |       454 |       454 |       454 |        43 |
| Time (wall clock) (μs) *    |    115527 |    116130 |    116457 |    117899 |    118489 |    120858 |    120858 |        43 |

### GMSetzer m5-composed-v1 parse-render syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       113 |       113 |       113 |       113 |       113 |       113 |       113 |        29 |
| Malloc (total) (K) *        |       458 |       458 |       459 |       459 |       459 |       459 |       459 |        29 |
| Time (wall clock) (μs) *    |    173804 |    174981 |    175505 |    176816 |    179962 |    183322 |    183322 |        29 |

