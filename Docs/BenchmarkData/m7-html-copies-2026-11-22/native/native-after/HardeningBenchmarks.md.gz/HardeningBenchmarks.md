
## Baseline 'Current_run'

```
Host 'PowerG5' with 4 'x86_64' processors with 31 GB memory, running:
#1 SMP PREEMPT_DYNAMIC Fri, 13 Nov 2026 19:45:18 +0000
```
## HardeningBenchmarks

### GMSetzer footnotes-repeated-v1 parse syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        58 |        58 |        58 |        58 |        58 |        58 |        58 |        65 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        65 |
| Time (wall clock) (μs) *    |     75574 |     76874 |     77332 |     77922 |     78774 |     80637 |     80637 |        65 |

### GMSetzer footnotes-repeated-v1 parse syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        69 |        69 |        69 |        69 |        69 |        69 |        69 |        55 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        55 |
| Time (wall clock) (μs) *    |     88840 |     91161 |     91554 |     92013 |     92537 |     93221 |     93221 |        55 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        92 |        92 |        92 |        92 |        92 |        92 |        92 |        39 |
| Malloc (total) (K) *        |       271 |       271 |       271 |       271 |       271 |       271 |       271 |        39 |
| Time (wall clock) (μs) *    |    127603 |    128516 |    128975 |    129499 |    130875 |    134599 |    134599 |        39 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       103 |       103 |       103 |       103 |       103 |       103 |       103 |        35 |
| Malloc (total) (K) *        |       271 |       271 |       271 |       271 |       271 |       271 |       271 |        35 |
| Time (wall clock) (μs) *    |    141116 |    142082 |    142868 |    143786 |    145752 |    152415 |    152415 |        35 |

### GMSetzer m5-composed-v1 parse syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        66 |        66 |        66 |        66 |        66 |        66 |        66 |        58 |
| Malloc (total) (K) *        |       283 |       284 |       284 |       284 |       284 |       284 |       284 |        58 |
| Time (wall clock) (μs) *    |     85248 |     85721 |     86180 |     86639 |     87753 |     94306 |     94306 |        58 |

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        98 |        98 |        98 |        98 |        98 |        98 |        98 |        35 |
| Malloc (total) (K) *        |       285 |       285 |       286 |       286 |       286 |       286 |       286 |        35 |
| Time (wall clock) (μs) *    |    145323 |    145883 |    146932 |    147718 |    148374 |    152820 |    152820 |        35 |

### GMSetzer m5-composed-v1 parse-render syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        80 |        80 |        80 |        80 |        80 |        80 |        80 |        44 |
| Malloc (total) (K) *        |       405 |       406 |       406 |       406 |       406 |       406 |       406 |        44 |
| Time (wall clock) (μs) *    |    112675 |    113181 |    113574 |    114164 |    115278 |    119321 |    119321 |        44 |

### GMSetzer m5-composed-v1 parse-render syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       111 |       111 |       111 |       111 |       111 |       111 |       111 |        28 |
| Malloc (total) (K) *        |       411 |       411 |       411 |       411 |       411 |       411 |       411 |        28 |
| Time (wall clock) (μs) *    |    178634 |    179306 |    179962 |    180617 |    181666 |    186531 |    186531 |        28 |

