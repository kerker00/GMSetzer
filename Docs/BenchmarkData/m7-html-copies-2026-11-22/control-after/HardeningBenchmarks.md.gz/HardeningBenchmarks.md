
## Baseline 'Current_run'

```
Host 'BlackBook.local' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer footnotes-repeated-v1 parse syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        59 |        59 |        59 |        59 |        59 |        59 |        59 |       103 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |       103 |
| Time (wall clock) (μs) *    |     47224 |     47809 |     48234 |     48923 |     49676 |     54854 |     61884 |       103 |

### GMSetzer footnotes-repeated-v1 parse syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        72 |        72 |        72 |        72 |        72 |        72 |        72 |        92 |
| Malloc (total) (K) *        |       184 |       184 |       184 |       184 |       184 |       184 |       184 |        92 |
| Time (wall clock) (μs) *    |     52847 |     53445 |     54067 |     54755 |     55542 |     70636 |     70636 |        92 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-off 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        92 |        92 |        92 |        92 |        92 |        92 |        92 |        62 |
| Malloc (total) (K) *        |       271 |       271 |       271 |       271 |       271 |       271 |       271 |        62 |
| Time (wall clock) (μs) *    |     78192 |     80019 |     80937 |     81920 |     82772 |     83689 |     83689 |        62 |

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 256 KiB (bytes: 262158, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       105 |       105 |       105 |       105 |       105 |       105 |       105 |        57 |
| Malloc (total) (K) *        |       271 |       271 |       271 |       271 |       271 |       271 |       271 |        57 |
| Time (wall clock) (μs) *    |     85920 |     86704 |     87556 |     88736 |     89522 |     91063 |     91063 |        57 |

### GMSetzer m5-composed-v1 parse syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        65 |        65 |        65 |        65 |        65 |        65 |        65 |        92 |
| Malloc (total) (K) *        |       260 |       260 |       260 |       260 |       260 |       260 |       260 |        92 |
| Time (wall clock) (μs) *    |     53355 |     53772 |     54657 |     55476 |     56132 |     57730 |     57730 |        92 |

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       101 |       101 |       101 |       101 |       101 |       101 |       101 |        54 |
| Malloc (total) (K) *        |       262 |       262 |       262 |       262 |       262 |       262 |       262 |        54 |
| Time (wall clock) (μs) *    |     90907 |     92209 |     93127 |     94044 |     94962 |     97238 |     97238 |        54 |

### GMSetzer m5-composed-v1 parse-render syntax-off 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        78 |        78 |        78 |        78 |        78 |        78 |        78 |        63 |
| Malloc (total) (K) *        |       376 |       376 |       376 |       376 |       376 |       376 |       376 |        63 |
| Time (wall clock) (μs) *    |     77670 |     79036 |     79495 |     80347 |     81002 |     84287 |     84287 |        63 |

### GMSetzer m5-composed-v1 parse-render syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       114 |       114 |       114 |       114 |       114 |       114 |       114 |        44 |
| Malloc (total) (K) *        |       378 |       378 |       378 |       378 |       378 |       378 |       378 |        44 |
| Time (wall clock) (μs) *    |    112142 |    113574 |    114164 |    115999 |    116982 |    118827 |    118827 |        44 |

