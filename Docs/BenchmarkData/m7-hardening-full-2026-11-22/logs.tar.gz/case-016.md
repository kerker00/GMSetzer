
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 16 KiB (bytes: 16398, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      6448 |      6448 |      6448 |      6448 |      6448 |      6448 |      6448 |       848 |
| Malloc (total) (K) *        |        28 |        28 |        28 |        28 |        28 |        28 |        28 |       848 |
| Time (wall clock) (μs) *    |      5791 |      5829 |      5853 |      5898 |      6017 |      6455 |      9237 |       848 |

