
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer long-emphasis-v1 parse syntax-off 64 KiB (bytes: 65542, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        11 |        11 |        11 |        11 |        11 |        11 |        11 |      4006 |
| Malloc (total) *            |        51 |        51 |        51 |        51 |        51 |        51 |        51 |      4006 |
| Time (wall clock) (μs) *    |      1153 |      1177 |      1195 |      1239 |      1315 |      1943 |     10713 |      4006 |

