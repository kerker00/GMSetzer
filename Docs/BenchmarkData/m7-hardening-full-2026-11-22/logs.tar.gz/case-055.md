
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer quote-overflow-v1 parse syntax-off 64 KiB (bytes: 65786, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        15 |        15 |        15 |        15 |        15 |        15 |        15 |      2779 |
| Malloc (total) *            |       185 |       185 |       185 |       185 |       185 |       185 |       185 |      2779 |
| Time (wall clock) (μs) *    |      1751 |      1763 |      1777 |      1799 |      1836 |      2165 |      8621 |      2779 |

