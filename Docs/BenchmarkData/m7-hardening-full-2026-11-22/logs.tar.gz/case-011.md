
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer m5-composed-v1 parse syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       103 |       103 |       103 |       103 |       103 |       103 |       103 |        53 |
| Malloc (total) (K) *        |       296 |       296 |       296 |       296 |       296 |       296 |       296 |        53 |
| Time (wall clock) (μs) *    |     92760 |     93061 |     93454 |     95224 |     97976 |    103031 |    103031 |        53 |

