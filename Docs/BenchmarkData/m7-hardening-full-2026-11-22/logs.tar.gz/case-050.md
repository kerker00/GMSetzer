
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer unmatched-backticks-v1 parse syntax-on 256 KiB (bytes: 262455, corpus: unmatched-backticks-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1935 |      1935 |      1935 |      1935 |      1935 |      1935 |      1935 |      6919 |
| Malloc (total) *            |      1489 |      1489 |      1489 |      1489 |      1489 |      1489 |      1489 |      6919 |
| Time (wall clock) (μs) *    |       709 |       715 |       717 |       723 |       736 |       781 |      1231 |      6919 |

