
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### cmark-gfm (C) long-emphasis-v1 parse 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      1027 |
| Malloc (total) (K) *        |        66 |        66 |        66 |        66 |        66 |        66 |        66 |      1027 |
| Time (wall clock) (μs) *    |      4741 |      4809 |      4825 |      4854 |      4891 |      5755 |     17525 |      1027 |

