
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer long-emphasis-v1 parse syntax-off 256 KiB (bytes: 262150, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        38 |        38 |        38 |        38 |        38 |        38 |        38 |      1000 |
| Malloc (total) *            |        56 |        56 |        56 |        56 |        56 |        56 |        56 |      1000 |
| Time (wall clock) (μs) *    |      4656 |      4743 |      4801 |      4952 |      5202 |      7594 |     29455 |      1000 |

