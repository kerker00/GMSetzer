
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### cmark-gfm (C) quote-overflow-v1 parse 256 KiB (bytes: 262626, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        31 |        31 |        31 |        31 |        31 |        31 |        31 |       282 |
| Malloc (total) (K) *        |       261 |       261 |       261 |       261 |       261 |       261 |       261 |       282 |
| Time (wall clock) (μs) *    |     16557 |     17400 |     17564 |     17842 |     18629 |     20398 |     22248 |       282 |

