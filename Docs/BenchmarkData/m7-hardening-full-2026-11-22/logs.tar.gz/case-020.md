
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer footnotes-repeated-v1 parse-render syntax-on 64 KiB (bytes: 65538, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        28 |        28 |        28 |        28 |        28 |        28 |        28 |       206 |
| Malloc (total) (K) *        |       110 |       110 |       110 |       110 |       110 |       110 |       110 |       206 |
| Time (wall clock) (μs) *    |     23935 |     24101 |     24166 |     24297 |     24773 |     28115 |     32633 |       206 |

