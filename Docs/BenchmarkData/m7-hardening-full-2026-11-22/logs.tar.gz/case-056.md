
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer quote-overflow-v1 parse syntax-on 64 KiB (bytes: 65786, corpus: quote-overflow-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        18 |        18 |        18 |        18 |        18 |        18 |        18 |      2396 |
| Malloc (total) *            |       215 |       215 |       215 |       215 |       215 |       215 |       215 |      2396 |
| Time (wall clock) (μs) *    |      2044 |      2057 |      2072 |      2093 |      2128 |      2343 |      4014 |      2396 |

