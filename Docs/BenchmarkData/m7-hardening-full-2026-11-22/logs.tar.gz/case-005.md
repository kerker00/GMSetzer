
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer m5-composed-v1 parse syntax-off 64 KiB (bytes: 65665, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        16 |        16 |        16 |        16 |        16 |        16 |        16 |       348 |
| Malloc (total) (K) *        |        66 |        66 |        66 |        66 |        66 |        66 |        66 |       348 |
| Time (wall clock) (μs) *    |     13536 |     13656 |     14041 |     14508 |     15245 |     20955 |     24476 |       348 |

