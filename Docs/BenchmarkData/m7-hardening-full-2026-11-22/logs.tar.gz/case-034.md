
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer long-emphasis-v1 parse syntax-off 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      2380 |      2380 |      2380 |      2380 |      2380 |      2380 |      2380 |     10000 |
| Malloc (total) *            |        45 |        45 |        45 |        45 |        45 |        45 |        45 |     10000 |
| Time (wall clock) (μs) *    |       286 |       290 |       290 |       292 |       297 |       320 |       523 |     10000 |

