
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer footnotes-repeated-v1 parse syntax-on 16 KiB (bytes: 16398, corpus: footnotes-repeated-v1, profile: gfm-footnotes, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      4253 |      4253 |      4253 |      4253 |      4253 |      4253 |      4253 |      1334 |
| Malloc (total) (K) *        |        18 |        18 |        18 |        18 |        18 |        18 |        18 |      1334 |
| Time (wall clock) (μs) *    |      3629 |      3676 |      3693 |      3744 |      3885 |      4510 |      9815 |      1334 |

