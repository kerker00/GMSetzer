
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer long-emphasis-v1 parse syntax-on 16 KiB (bytes: 16390, corpus: long-emphasis-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      4214 |      4214 |      4214 |      4214 |      4214 |      4214 |      4214 |      2593 |
| Malloc (total) (K) *        |        16 |        16 |        16 |        16 |        16 |        16 |        16 |      2593 |
| Time (wall clock) (μs) *    |      1843 |      1867 |      1881 |      1906 |      1978 |      2812 |      8680 |      2593 |

