
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### cmark-gfm (C) quote-overflow-v1 parse 64 KiB (bytes: 65786, corpus: quote-overflow-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      7859 |      7859 |      7859 |      7859 |      7859 |      7859 |      7859 |      1454 |
| Malloc (total) (K) *        |        65 |        65 |        65 |        65 |        65 |        65 |        65 |      1454 |
| Time (wall clock) (μs) *    |      3337 |      3402 |      3422 |      3451 |      3480 |      3736 |      9931 |      1454 |

