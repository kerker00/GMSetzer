
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### cmark-gfm (C) unmatched-backticks-v1 parse 64 KiB (bytes: 65708, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |       715 |       715 |       715 |       715 |       715 |       715 |       715 |     10000 |
| Malloc (total) *            |       759 |       759 |       759 |       759 |       759 |       759 |       759 |     10000 |
| Time (wall clock) (μs) *    |       128 |       129 |       129 |       129 |       133 |       157 |       386 |     10000 |

