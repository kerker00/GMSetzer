
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer unmatched-backticks-v1 parse syntax-off 256 KiB (bytes: 262455, corpus: unmatched-backticks-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      1935 |      1935 |      1935 |      1935 |      1935 |      1935 |      1935 |      6849 |
| Malloc (total) *            |      1489 |      1489 |      1489 |      1489 |      1489 |      1489 |      1489 |      6849 |
| Time (wall clock) (μs) *    |       710 |       716 |       719 |       729 |       747 |       860 |     10107 |      6849 |

