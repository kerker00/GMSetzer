
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer open-brackets-v1 parse syntax-on 64 KiB (bytes: 65536, corpus: open-brackets-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        44 |        44 |        44 |        44 |        44 |        44 |        44 |      1031 |
| Malloc (total) *            |        70 |        70 |        70 |        70 |        70 |        70 |        70 |      1031 |
| Time (wall clock) (μs) *    |      4320 |      4551 |      4686 |      4878 |      5177 |      7459 |     27377 |      1031 |

