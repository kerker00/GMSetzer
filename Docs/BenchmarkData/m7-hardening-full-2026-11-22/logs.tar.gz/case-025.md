
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer open-brackets-v1 parse syntax-off 16 KiB (bytes: 16384, corpus: open-brackets-v1, profile: commonmark, syntax: off)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        13 |        13 |        13 |        13 |        13 |        13 |        13 |      4629 |
| Malloc (total) *            |        63 |        63 |        63 |        63 |        63 |        63 |        63 |      4629 |
| Time (wall clock) (μs) *    |      1041 |      1059 |      1066 |      1078 |      1104 |      1294 |      4474 |      4629 |

