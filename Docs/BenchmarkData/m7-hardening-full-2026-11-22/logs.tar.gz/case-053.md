
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer quote-overflow-v1 parse syntax-on 16 KiB (bytes: 16576, corpus: quote-overflow-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (K) *  |      4975 |      4975 |      4975 |      4975 |      4975 |      4975 |      4975 |      9310 |
| Malloc (total) *            |       110 |       110 |       110 |       110 |       110 |       110 |       110 |      9310 |
| Time (wall clock) (μs) *    |       523 |       526 |       528 |       536 |       550 |       616 |      8761 |      9310 |

