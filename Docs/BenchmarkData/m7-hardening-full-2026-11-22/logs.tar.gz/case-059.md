
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer quote-overflow-v1 parse syntax-on 256 KiB (bytes: 262626, corpus: quote-overflow-v1, profile: commonmark, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |        70 |        70 |        70 |        70 |        70 |        70 |        70 |       572 |
| Malloc (total) *            |       605 |       605 |       605 |       605 |       605 |       605 |       605 |       572 |
| Time (wall clock) (μs) *    |      8351 |      8471 |      8528 |      8651 |      8954 |     12935 |     40868 |       572 |

