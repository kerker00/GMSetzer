
## Baseline 'Current_run'

```
Host '[redacted]' with 8 'arm64' processors with 16 GB memory, running:
Darwin Kernel Version 27.0.0: Tue Aug 11 21:02:16 PDT 2026; root:xnu-13432.1.9~1/RELEASE_ARM64_T8112
```
## HardeningBenchmarks

### GMSetzer m5-composed-v1 parse-render syntax-on 256 KiB (bytes: 262177, corpus: m5-composed-v1, profile: gfm-all-m5, syntax: on)

| Metric                      |        p0 |       p25 |       p50 |       p75 |       p90 |       p99 |      p100 |   Samples |
|:----------------------------|----------:|----------:|----------:|----------:|----------:|----------:|----------:|----------:|
| Malloc (bytes total) (M) *  |       118 |       118 |       118 |       118 |       118 |       118 |       118 |        43 |
| Malloc (total) (K) *        |       458 |       458 |       458 |       458 |       458 |       458 |       458 |        43 |
| Time (wall clock) (μs) *    |    115954 |    116195 |    116326 |    116589 |    117834 |    140779 |    140779 |        43 |

